#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  users_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################



def handler_users(type, source, parameters):
	room = parameters
	iq = xmpp.Iq('get')
	iq.setID('ulti_users')
	iq.setTo(room+'@conference.nimbuzz.com')
	query = xmpp.Node('query')
	query.setNamespace('http://jabber.org/protocol/disco#items')
	iq.addChild(node=query)
	JCON.SendAndCallForResponse(iq, handler_users_answ, {'type': type, 'source': source})
	return

def handler_users_answ(coze, res, type, source):
    rep='Empty.'
    if res:
        if res.getType() == 'result':
            aa=res.getQueryChildren()
            if aa:
                rep=''
                for x in aa:
                    m=x.getAttr('jid')
                    if m:
                        nicks=m.split('/')[1]
                        rep+=nicks
                        rep+='\n'
    reply(type, source, rep)
 
register_command_handler(handler_users, '.users', ['info','muc','all'], 0, 'Shows the users currently in a room.', '.users <room jid', ['.users indian~good~friends'])
            