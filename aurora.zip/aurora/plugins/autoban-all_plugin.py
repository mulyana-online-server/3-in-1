#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  autoban-all_plugin.py
#  coded by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################


def handler_autobanall(groupchat, nick, reason):
   iq = xmpp.Iq('set')
   iq.setID('ban'+str(random.randrange(1000, 9999)))
   iq.setTo(groupchat)
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#admin')
   ban=query.addChild('item', {'jid':nick+'@nimbuzz.com', 'affiliation':'outcast'})
   ban.setTagData('reason', get_bot_nick(groupchat)+u': '+reason)
   iq.addChild(node=query)
   JCON.send(iq)
   
def autobanall_join(groupchat, nick, aff, role):
	DBPATH='dynamic/'+groupchat+'/config.cfg'
	if GCHCFGS[groupchat].has_key('autobanall'):
		pass
	else:
		GCHCFGS[groupchat]['autobanall']=0
	write_file(DBPATH,str(GCHCFGS[groupchat]))
	if GCHCFGS[groupchat]['autobanall']==1:
		if aff in ('owner', 'admin', 'member'):
			return
		else:
			handler_autobanall(groupchat, nick, u'Autoban is active')
	if nick == DEFAULT_NICK:
		if GCHCFGS[groupchat].has_key('autobanall'):
			if GCHCFGS[groupchat]['autobanall']==1:
				msg(ADMINS[0], u'NOTIFICATION :\nAutoban on enterence is active in '+groupchat+'\nSend "autobanall 0" to De-Activate it')
   
def handler_autobanall_onoff(type, source, parameters):

	if not source[1] in GROUPCHATS:
		reply(type, source, u'This command only possible in the conference')
		return
	if parameters:
		try:
			parameters=int(parameters.strip())
		except:
			reply(type,source,u'read "help autobanall"')
			return		
		DBPATH='dynamic/'+source[1]+'/config.cfg'
		if parameters==1:
			if GCHCFGS[source[1]]['autobanall']==1:
				reply(type,source,u'Autoban-All is Already Enabled !')
				return
			else:
				GCHCFGS[source[1]]['automember']=0
				GCHCFGS[source[1]]['autobanall']=1
				reply(type,source,u'Autoban-All Enabled !')
				pass
		else:
			GCHCFGS[source[1]]['autobanall']=0
			reply(type,source,u'Autoban-All Disabled')
		write_file(DBPATH,str(GCHCFGS[source[1]]))
		if GCHCFGS[source[1]]['autobanall']==1:
			msg(ADMINS[0], u'NOTIFICATION :\nAutoban Activated in '+source[1]+'\nSend "autobanall 0" to De-Activate it')
	else:
		ison=GCHCFGS[source[1]]['autobanall']
		if ison==1:
			reply(type,source,u'Autoban-All is Enabled here')
		else:
			reply(type,source,u'Autoban-All is Disabled here')	
   


register_join_handler(autobanall_join)
register_command_handler(handler_autobanall_onoff, 'autobanall', ['admin','muc','all'], 100, 'Off (0) On (1) bot will ban to all user ids below than member role', 'autobanall [conf] [1|0]', ['autobanall 1','autobanall 0','autobanall'])
