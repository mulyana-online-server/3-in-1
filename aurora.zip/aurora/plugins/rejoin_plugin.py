#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  rejoin_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################


def handler_rejoinall(type, source, parameters):
	if check_file(file='chatrooms.list'):
		lgcts = eval(read_file(GROUPCHAT_CACHE_FILE))
		for groupchat in lgcts: #GROUPCHATS:
			prs=xmpp.Presence(groupchat, 'unavailable')
			JCON.send(prs)
			gc=lgcts[groupchat]  #GROUPCHATS[grc]
			join_groupchat(groupchat,gc['nick'],gc['passw'])
	else:
		print 'Error: unable to create chatrooms list file!'

register_command_handler(handler_rejoinall, 'rejoin', ['admin','muc','all'], 100, 'Rejoin bot to conferences according to database.', 'rejoin', ['rejoin'])
