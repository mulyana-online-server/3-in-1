#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  railway_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

import urllib
import urllib2
import webbrowser
 
def railways(type, source, parameters):
	url = "http://duckduckgo.com/html"
	data = urllib.urlencode({'q': 'sex'})
	results = urllib2.urlopen(url, data)
	with open("results.html", "w") as f:
		f.write(results.read())
	webbrowser.open("results.html")
	reply(type, source, parameters)

register_command_handler(railways, 'rail', ['info','all'], 0, '', 'wiki <term>', ['wiki kingfisher'])