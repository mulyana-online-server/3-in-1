﻿#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  ext_plugin.py
#  coded by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################




import urllib2,re,urllib
from re import compile as re_compile
strip_tags = re_compile(r'<[^<>]+>')

def handler_ext(type, source, parameters):
	if parameters:
		try:
			req = urllib2.Request('http://www.file-extensions.org/'+parameters.encode('windows-1251')+'-file-extension')		
			r = urllib2.urlopen(req)
			target = r.read()
			od = re.search('<div class="boxextdesc" itemtype="description"><p>',target)
			message = target[od.end():]
			message = message[:re.search('<br />',message).start()]
			message = decode(message)		
			message = u'Result for ' +'.\n' + unicode(message,'windows-1251')
			if len(message)>30:
				reply(type, source, u'Send To Private')
                        	reply('private', source, message)
				return
			else:
				reply(type, source, message)
				return
			
		except:
			reply(type,source,u'nothing to find :-(')
			return
	else:
		reply(type,source,u'Enter title of extension')
	

def decode(text):
    return strip_tags.sub('', text.replace('<br />','').replace('<br>','')).replace('&nbsp;', ' ').replace('&lt;', '<').replace('&gt;', '>').replace('&quot;', '"').replace('\t','').replace('||||:]','').replace('>[:\n','')

register_command_handler(handler_ext, '.ext', ['all'], 0, 'find description of extention ', '.ext <word>', ['.ext rar'])
