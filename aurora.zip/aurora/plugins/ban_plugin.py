#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  ban_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################


def handler_banaf(type, source, parameters):
   count= parameters.split()[1]
   how = parameters.split()[2]
   jid = parameters.split()[0]
   iq = xmpp.Iq('set')
   iq.setID('ulti_ban')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#admin')
   for i in range(int(count), int(how)):
      count= int(count) + 1
      
      
      query.addChild('item', {'jid':jid+str(count)+'@nimbuzz.com', 'affiliation':'outcast'})
   iq.addChild(node=query)
   JCON.SendAndCallForResponse(iq, handler_ban_answ, {'type': type, 'source': source})





def handler_banbe(type, source, parameters):
   count= parameters.split()[1]
   how = parameters.split()[2]
   jid = parameters.split()[0]
   iq = xmpp.Iq('set')
   iq.setID('ulti_ban')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#admin')
   for i in range(int(count), int(how)):
      count= int(count) + 1
      
      
      query.addChild('item', {'jid':str(count)+jid+'@nimbuzz.com', 'affiliation':'outcast'})
   iq.addChild(node=query)
   JCON.SendAndCallForResponse(iq, handler_ban_answ, {'type': type, 'source': source})






def handler_banbt(type, source, parameters):
   count= parameters.split()[1]
   how = parameters.split()[2]
   jid = parameters.split()[0]
   iq = xmpp.Iq('set')
   iq.setID('ulti_ban')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#admin')
   for i in range(int(count), int(how)):
      count= int(count) + 1
      
      
      query.addChild('item', {'jid':jid+'-'+str(count)+'-@nimbuzz.com', 'affiliation':'outcast'})
   iq.addChild(node=query)
   JCON.SendAndCallForResponse(iq, handler_ban_answ, {'type': type, 'source': source})

def handler_banbt1(type, source, parameters):
   count= parameters.split()[1]
   how = parameters.split()[2]
   jid = parameters.split()[0]
   iq = xmpp.Iq('set')
   iq.setID('ulti_ban')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#admin')
   for i in range(int(count), int(how)):
      count= int(count) + 1
      
      
      query.addChild('item', {'jid':jid+str(count)+jid+'@nimbuzz.com', 'affiliation':'outcast'})
   iq.addChild(node=query)
   JCON.SendAndCallForResponse(iq, handler_ban_answ, {'type': type, 'source': source})


def handler_ban_answ(coze, res, type, source):
   if res:
      if res.getType() == 'result':
         reply(type, source, u'Banned.')
      else:
         
         reply(type, source, u'Error. Try again, or ban less quantity.')





register_command_handler(handler_banaf, 'ban-', ['info','muc','all'], 20, 'Ban serial IDs with number after', 'ban-', ['ban-'])
register_command_handler(handler_banbe, '-ban', ['info','muc','all'], 20, 'Ban serial IDs with number before', '-ban', ['-ban'])
register_command_handler(handler_banbt, '-ban-', ['info','muc','all'], 20, 'Ban serial IDs with number between --', '-ban-', ['-ban-'])
register_command_handler(handler_banbt1, '-b-n-', ['info','muc','all'], 20, 'Ban serial IDs with number between two same words', '-b-n-', ['-b-n-'])
