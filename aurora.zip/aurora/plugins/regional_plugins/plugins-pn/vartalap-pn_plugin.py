#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  vartalap-pn_plugin.py
#  coded by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

def handler_bot_(type, source, parameters):
       replies = [u'haa:):)', u'haa bol:):)', u'haa bol ki hoya :)(:|', u'bol hunn ki bimari aI-) ', u'mera dimag na kha oye I-) (:| ']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_hi_(type, source, parameters):
        replies = [u'Hi in ssa keh:-):-)', u'_/\_ ssa g :-):-)', u'sat sri akal gi _/\_  :D', u'ssa kho yr I-) :D:P', u'hlo ki haal a tera :):|', u' tenu sunda ni oye :@ ssa keh I-)' ]
        balas = random.choice(replies)
        if type == 'public':
                if source[1]:
                        reply(type, source, balas)
        elif type == 'private':
                reply(type, source, balas)
				
def handler_ssa_(type, source, parameters):
        replies = [u':-) SAT SRI AKAL GI :)', u'SSA G _/\_ :-)(f):-)', u' WAHEGURU JI KA KHALSA WAHEGURU JI K FATEH:) (F)']
        balas = random.choice(replies)
        if type == 'public':
                if source[1]:
                        reply(type, source, balas)
        elif type == 'private':
                reply(type, source, balas)
				
def handler_salam_(type, source, parameters):
        replies = [u':-) WALAIKUM ASsalam:)', u'walaikumsalam :-):-)', u'wa\' alaikumsalam :)(f)', u'wa\' alaikumsalam :-)(f)', u'ws :) (f)']
        balas = random.choice(replies)
        if type == 'public':
                if source[1]:
                        reply(type, source, balas)
        elif type == 'private':
                reply(type, source, balas)


def handler_leaving_(type, source, parameters):
        replies = [u'ja bhaj ja nai ta krwalega kush mereto :D:P ', u'ja ghum fir a ja k :P bye', u'ok jao g jao :(:P', u'chal dfa ho :D', u' fer aouna g :)']
        balas = random.choice(replies)
        if type == 'public':
                if source[1]:
                        reply(type, source, balas)
        elif type == 'private':
                reply(type, source, balas)

def handler_thanks_(type, source, parameters):
       replies = [u'mera pleasure :):)', u'apna plenjr g :):D', u' pleasure is all miine :):|(oye mainu v greji aoundi a :D)']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_gali_(type, source, parameters):
       replies = [u':@ gaal na kadd oye mai v kaddu fr :@ ', u':@ room ch gaal na kadh bahar jayega :@ :@ ', u' j hun gaal kaddi ta chittra te latt pau :D']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)
			   
def handler_fine_(type, source, parameters):
       replies = [u'mai v full kaim g:d :p ', u' fine:O mai full kaim :d :p ']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)


def handler_chup_(type, source, parameters):
       replies = [u'mai ta ed e bolu patla jo patna :p:D ', u'chup nahi hoya ta ki krenga :|:|I-) ']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)


def handler_gana_(type, source, parameters):
       replies = [u'pele lalkare naal mai dargi, 2je lalkare ch andar wrgi, 3je lalkare naal na mera lai k, pattu aan k dra de vich wajya:| ni pattu firda sharrab naal rajya', u'ki samjhaiye sajna ehna nain kamlya nu :) kehnde tenu dekhe bina guzara ni hunda :):$', u'pehla kaat bhukki da launde fr stering nu hath paunde ni bane da naam dhya k seena taan lai da;) 100 koh to purja pachan lai da :D']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)
			   
def handler_jattsong_(type, source, parameters):
       replies = [u'hathi far k dndhook 12bor di :@ verry tai aaj dassna , ;) j paindi a dushmni paije dar k ni piche hatna :@:@:@', u'jatt siwya cho langya chudail takkri:P jaani bdi sohni bhoot femail takkri :P:P:D ', u'mukgi feem dabbi cho yaaro:(, aaj koi amli da dang saaro :( saadi russi fire kartaro kon manawe heer nu :S, haye jind nikal challi laggi tod shareer nu :( :|', u'paya lehnga sheeshya wala tu sara patt sutya patiala:P ni munda marju murabya wala deja jhake ni kude;)khabbi akh de thale til kala krda baake ni kudie :):P', u'padhn padhaiya pindo sher kaadi aai ;) shehar kadi aai sare machgi duhai bnke swal munde khre raha de vich :| kehnde asi a tere te marde :O ni ludiahne sher de munde gall akkh de ishare nl krde ;)']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)
			   
def handler_sadsong_(type, source, parameters):
       replies = [u'ehna hanjua da ki kriye:( jo paani bn wehnde ne :( tutte dila da ki kriye (u) jo tere gam sehnde ne :( ', u'ro ro k arza guzaar da e <3 haye mera <3 haye mera <3 jagg hi nazra to chori kite mil haye mera<3 :( ', u'naina de harf padhawa kiwe <3 te likhia padhawa kiwe:( ehna socha vich rehna <3 nu aksar kehna jehri ishq ch chaldi hai, ohde rang vich dhaldi hai,o nabz pachane na :| mera peer jane meri peed oh jane na :(', u' dekhi jidi jeb bhaari :( laali ohde naal yaari :| dob jandia ne adh vichkaar e laundia na paar mittro :( dhokhe baaz ne mashhoka aaj kall dia kro na pyar mittro :(' ]
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_romanticsong_(type, source, parameters):
       replies = [u'kon tenu nu wraunda jaane merie :( jdo mera pyar chete aounda jaane merie :(:( ', u' padam naag da dangya bachgya:$ dushman muhre khangya bachgya :p kitho-2 aje takk bachda reha ni kithe kha gya maar vichara :( ni eh teri akh da kaara;):P ', u'ghare gai na laru gi meri maa j veeni utey daag paigya haye :P ', u' sangda chann os kudi to amra te charda ne ;) :P', u'gori dia goria baha ch kangna kangne te mittra da na likhya :P:$' ]
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)


def handler_desisong_(type, source, parameters):
       replies = [u'j ikk wari jatt ne gandasa chklya ni delhi hilju sohiye:@:D', u'vich pira de pain patake 12bora de ;)', u'yaaro sher chandigar dia kudia :P att ne v att ne v att ne ;) :P :D', u' manya k moodi hege g madam fukre na, pr <3 lain wali koi sanu takkre na :P :$ :)', u'adhi kikk ta start mera yamha :D tu ho dass ki bhalda :-ss']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)
			   
def handler_kiwe_(type, source, parameters):
       replies = [u'wadia tu sna;)', u' full kaim apna sna;),' u'kamm tait a :| jyada chargi aaj :D', u'maare haal ne feem ni mildi :(', u'dukhi a bhukki mukgi:( tu sna ?', u'kaato fulla te a :Dtu sna?' ]
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)
			   
def handler_chamkila_(type, source, parameters):
       replies = [u'lukan mitti khel bnaiye;) dono janne g parchaiye :P teri chandi de rupaiye wangu naat khanke:| hikk utey saunja ve sharaabi bn k:P;)', u'ni mai ho k sharaabi aouna , tenu sutti nu jdo jgauna :| thoku kach m kalai jaawe hikk cheer di;), teh la k chaddu gundwe shareer di ;):P', u'jine laal pari na piti rann kutt k sidhi na ketti:D naale nasha pani naal peena daso ohda jagg te ki jeena :D']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_velly_(type, source, parameters):
       replies = [u'veer tere firde ne daanga modhe chakki jatt ne dunali pakki gaddi vich rakhi:@ nikki jehi gall ditti kinni tu wdha sade ghar lambha laike aagi teri ma:@ puchya c na kehda farli c bah sade ghar lamba laike agi teri ma I-)', u' 10vi de vich badmashi shuru krti math ali madam c yaaro asi farli, :| khndi kaka tenu kush padhna ni aounda I-) tere hatho ta padhai di lakeer margi :| taio jatta nu pahai hunzehar wrgi I-):D']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_dharmik_(type, source, parameters):
       replies = [u'di kachairy 4re paase khade verry,:) chote chote bachya ne pr himmat na haari jo bole sonihaal bolkeO:), neeha vich khar jange, gobind de laalsoobya samjhi na dr jange :@', u' deh shiwa war mohe eha subh karman te kbhu na tru :@ na dru arso jb jaye lru nishe kr apni jeet kru :) ', u'bhan naanki da veer tann mann da fakeer:) ni e jogi a da jogi O:) peera da peer:) (f)']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_bakkra_(type, source, parameters):
       replies = [u'bbbbbbbuuuuuuuuuuuuuuuuuuuuurrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrraaaaaaaaaaaaaaaaa.................:@:@:@:@:@:@:@']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)
			   
def handler_ac_(type, source, parameters):
        if not parameters:
                reply(type, source, u'AC ON/OFF')
        if parameters:
                if parameters=='on':
                        msg(source[1],u'Activating K-AC™...')
			time.sleep(10.0)
                        msg(source[1],u'k-AC™ Activated \nenjoy supercool Environment')
                elif parameters=='off':
                        msg(source[1],u'De-Activating K-AC™...')
			time.sleep(10.0)
                        msg(source[1],u'K-AC™ De-Activated')
                else:
                        reply(type,source,u'contact engineer !!!')


def handler_music_(type, source, parameters):
        if not parameters:
                reply(type, source, u'MUSIC ON/OFF')
        if parameters:
                if parameters=='on':
                        msg(source[1],u'Activating K-blaster™...')
			time.sleep(10.0)
                        msg(source[1],u'K-blaster™ Activated \nEnjoy 18,000 watt Woofers with Dolby™ Digital sound')
                elif parameters=='off':
                        msg(source[1],u'De-Activating K-blaster™...')
			time.sleep(10.0)
                        msg(source[1],u'K-blaster™ De-Activated')
                else:
                        reply(type,source,u'contact engineer !!!')


def handler_dance_(type, source, parameters):
       replies = [u'\n\:-D/ \n<:-D/ \n\:-P> \n\;-)> \n<:-D> \nkaisa laga mera chamiya dance?:-D', u'\n\:-P> \n\:-D/ \n\:-P> \n<:-D/ \n<:-D> \nmunni badnam hui ,darling tere liye..:$']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)


def handler_lights_(type, source, parameters):
        if not parameters:
                reply(type, source, u'LIGHTS ON/OFF')
        if parameters:
                if parameters=='on':
                        msg(source[1],u'LIGHTS ON')
                elif parameters=='off':
                        msg(source[1],u'LIGHTS OFF')
                else:
                        msg(source[1],u'contact engineer !!!')

def handler_help_(type, source, parameters):
       replies = [u'ah galla da mai jwab dau :- ac,music,lights,fact,song,maker,joke,english,kf,help,shayari,sher']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)




register_command_handler(handler_bot_, 'bot', ['new'], 0, '', '', [''])
register_command_handler(handler_leaving_, 'brb', ['new'], 0, '', '', [''])
register_command_handler(handler_leaving_, 'bye', ['new'], 0, '', '', [''])
register_command_handler(handler_leaving_, 'byee', ['new'], 0, '', '', [''])
register_command_handler(handler_leaving_, 'tc', ['new'], 0, '', '', [''])
register_command_handler(handler_leaving_, 'gn', ['new'], 0, '', '', [''])
register_command_handler(handler_leaving_, 'gn8', ['new'], 0, '', '', [''])
register_command_handler(handler_leaving_, 'g98', ['new'], 0, '', '', [''])
register_command_handler(handler_leaving_, 'sd', ['new'], 0, '', '', [''])
register_command_handler(handler_leaving_, 'ah', ['new'], 0, '', '', [''])
register_command_handler(handler_leaving_, 'cya', ['new'], 0, '', '', [''])
register_command_handler(handler_hi_, 'hi', ['new'], 0, '', '', [''])
register_command_handler(handler_hi_, 'hii', ['new'], 0, '', '', [''])
register_command_handler(handler_hi_, 'hii1', ['new'], 0, '', '', [''])
register_command_handler(handler_hi_, 'hello', ['new'], 0, '', '', [''])
register_command_handler(handler_hi_, 'helo', ['new'], 0, '', '', [''])
register_command_handler(handler_hi_, 'halo', ['new'], 0, '', '', [''])
register_command_handler(handler_hi_, 'hey', ['new'], 0, '', '', [''])
register_command_handler(handler_hi_, 'heya', ['new'], 0, '', '', [''])
register_command_handler(handler_hi_, 'hiya', ['new'], 0, '', '', [''])
register_command_handler(handler_ssa_, 'ssa', ['new'], 0, '', '', [''])
register_command_handler(handler_ssa_, 'sat sri akal', ['new'], 0, '', '', [''])
register_command_handler(handler_ssa_, 'satsriakal', ['new'], 0, '', '', [''])
register_command_handler(handler_salam_, 'salam', ['new'], 0, '', '', [''])
register_command_handler(handler_salam_, 'salaam', ['new'], 0, '', '', [''])
register_command_handler(handler_salam_, 'assalaam', ['new'], 0, '', '', [''])
register_command_handler(handler_salam_, 'asalaam', ['new'], 0, '', '', [''])
register_command_handler(handler_salam_, 'asalam', ['new'], 0, '', '', [''])
register_command_handler(handler_salam_, 'assalam', ['new'], 0, '', '', [''])
register_command_handler(handler_salam_, 'assalaamwalaekum', ['new'], 0, '', '', [''])
register_command_handler(handler_salam_, 'asalaamwalaekum', ['new'], 0, '', '', [''])
register_command_handler(handler_salam_, 'assalaamwalaikum', ['new'], 0, '', '', [''])
register_command_handler(handler_salam_, 'asalaamwalaikum', ['new'], 0, '', '', [''])
register_command_handler(handler_thanks_, 'thanx', ['new'], 0,'', '', [''])
register_command_handler(handler_thanks_, 'thx', ['new'], 0, '', '', [''])
register_command_handler(handler_thanks_, 'thanks', ['new'], 0, '', '', [''])
register_command_handler(handler_thanks_, 'ty', ['new'], 0, '', '', [''])
register_command_handler(handler_thanks_, 'tx', ['new'], 0, '', '', [''])
register_command_handler(handler_thanks_, 'tq', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'madarchod', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'kutiya', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'gandu', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'gaandu', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'chutiya', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'chutiye', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'chootiya', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'chootiye', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'randi', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'raand', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'rand', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'bhosda', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'bhosdi', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'gand', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'gaand', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'chut', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'choot', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'sali', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'behanchod', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'land', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'lund', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'lauda', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'laude', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'loda', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'lode', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'chinal', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'harami', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'chodu', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'fudu', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'fudi', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'fuddu', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'fuddi', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'fuck', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'fuckoff', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'asshole', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'fucker', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'pussy', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'boobs', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'gay', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'motherfuckker', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'dick', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'pens', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'vegina', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'clitoris', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'moron', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'hore', ['new'], 0, '', '', [''])
register_command_handler(handler_fine_, '59', ['new'], 0, '', '', [''])
register_command_handler(handler_fine_, 'f9', ['new'], 0, '', '', [''])
register_command_handler(handler_fine_, 'fine', ['new'], 0, '', '', [''])
register_command_handler(handler_fine_, 'fn', ['new'], 0, '', '', [''])
register_command_handler(handler_fine_, '5n', ['new'], 0, '', '', [''])
register_command_handler(handler_fine_, 'good', ['new'], 0, '', '', [''])
register_command_handler(handler_fine_, 'gud', ['new'], 0, '', '', [''])
register_command_handler(handler_fine_, 'mast', ['new'], 0, '', '', [''])
register_command_handler(handler_fine_, 'good', ['new'], 0, '', '', [''])
register_command_handler(handler_fine_, 'gud', ['new'], 0, '', '', [''])
register_command_handler(handler_fine_, 'mast', ['new'], 0, '', '', [''])
register_command_handler(handler_chup_, 'chup', ['new'], 0, '', '', [''])
register_command_handler(handler_gana_, 'song', ['new'], 0, '', '', [''])
register_command_handler(handler_gana_, 'gana', ['new'], 0, '', '', [''])
register_command_handler(handler_gana_, 'gaana', ['new'], 0, '', '', [''])
register_command_handler(handler_jattsong_, 'jatt.sng', ['new'], 0, '', '', [''])
register_command_handler(handler_sadsong_, 'sad.sng', ['new'], 0, '', '', [''])
register_command_handler(handler_romanticsong_, 'romantic.sng', ['new'], 0, '', '', [''])
register_command_handler(handler_desisong_, 'desi.sng', ['new'], 0, '', '', [''])
register_command_handler(handler_kiwe_, 'kiwe', ['new'], 0, '', '', [''])
register_command_handler(handler_kiwe_, 'kidda', ['new'], 0, '', '', [''])
register_command_handler(handler_kiwe_, 'ki haal a', ['new'], 0, '', '', [''])
register_command_handler(handler_kiwe_, 'ki haal', ['new'], 0, '', '', [''])
register_command_handler(handler_kiwe_, 'kaise', ['new'], 0, '', '', [''])
register_command_handler(handler_dharmik_, 'dharmik', ['new'], 0, '', '', [''])
register_command_handler(handler_velly_, 'velly.sng', ['new'], 0, '', '', [''])
register_command_handler(handler_chamkila_, 'chamkila', ['new'], 0, '', '', [''])
register_command_handler(handler_bakkra_, 'bakkra', ['new'], 0, '', '', [''])
register_command_handler(handler_bakkra_, 'bakra', ['new'], 0, '', '', [''])
register_command_handler(handler_ac_, 'ac', ['new'], 0, '', '', [''])
register_command_handler(handler_music_, 'music', ['new'], 0, '', '', [''])
register_command_handler(handler_dance_, 'dance', ['new'], 0, '', '', [''])
register_command_handler(handler_dance_, 'nach', ['new'], 0, '', '', [''])
register_command_handler(handler_dance_, 'naach', ['new'], 0, '', '', [''])
register_command_handler(handler_lights_, 'lights', ['new'], 0, '', '', [''])
register_command_handler(handler_help_, 'help', ['new'], 0, '', '', [''])