#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  bomb-en_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

COLOR = [u'red',u'green',u'black',u'blue',u'white',u'yellow',u'gray',u'orange',u'purple']
PROVOD =[]
FLL={}
FLL2={}
BOMB_FRA=[u' Gone to space :D',u' blown up :D',u' is in the sky :D :-D',u' gone :D']
def bomb_send(type, source, parameters):
		if type=='private':
				reply(type,source,u'Allowed only in the conference !')
				return
		else:
			if not parameters:
					reply(type, source, u'Whom ?')
					return
			if not parameters in GROUPCHATS[source[1]]:
					reply(type,source,u'Where is '+parameters+' ?')
					return
			if parameters in FLL2:
					reply(type,source,u'hehehe :D, '+parameters+u' already has a bomb in his pants !')
					return
			if not parameters:
					parameters=source[2]
			tim = random.randrange(20,45)
			e = u', You are presented with a bomb, with '
			rd = random.randrange(15,27)
			hh = random.choice(COLOR)
			d =''
			for x in COLOR:
					if len(d)<rd:
							d +=x+', '
							#print d
							PROVOD.append(x)
							if not parameters in FLL:
									FLL[parameters]={'w':1}
							else:
									FLL[parameters]['w']+=1
			s = random.choice(PROVOD)
			#print s,'prav'
			FLL2[parameters]={'answ':s}
			l = unicode(FLL[parameters]['w'])
			msg(source[1],u'/me '+parameters+e+l+u' wires on it : '+d+u' Select the colour you want to cut the wire, hurry ! you have '+unicode(tim)+u' seconds.')
			PROVOD.remove(s)
			del FLL[parameters]
			bomb_start(source[1],parameters,tim)

def kick_bomb(groupchat, nick, reason=''):
        iq = xmpp.Iq('set')
        iq.setTo(groupchat)
        iq.setID('kick'+str(random.randrange(1000, 9999)))
        query = xmpp.Node('query')
        query.setNamespace('http://jabber.org/protocol/muc#admin')
        kick=query.addChild('item', {'nick':nick, 'role':'none'})
        kick.setTagData('reason', get_bot_nick(groupchat)+': '+reason)
        iq.addChild(node=query)
        JCON.send(iq)
        time.sleep(0.1)
        jid=get_true_jid(groupchat+'/'+nick)
        try:
                if groupchat in order_stats and jid in order_stats[groupchat]:
                        order_stats[groupchat][jid]['kicks']=0
        except:
                pass

def bomb_start(groupchat,nick,tim):
        time.sleep(tim)
        if nick in FLL2 and nick in GROUPCHATS[groupchat]:
                kick_bomb(groupchat,nick,u'Boooooommmmmmmm !! Correct wire was : '+FLL2[nick]['answ'])
                rep=random.choice(BOMB_FRA)
                msg(groupchat, u'/me '+nick+rep)
                del FLL2[nick]
                
def bomb_msg(type,source,parameters):
	if source[1] not in GROUPCHATS:
                return
	else:
		if parameters in COLOR:
			if source[2] in FLL2:
				ad = parameters.lower()
				if ad in FLL2[source[2]]['answ']:
						msg(source[1],u'/me '+source[2]+u', Bomb Defused ! good work (f)')
						del FLL2[source[2]]
						return
				else:
						kick_bomb(source[1],source[2],u'Boooooommmmmmmm !! Correct wire was : '+FLL2[source[2]]['answ'])
						rep=random.choice(BOMB_FRA)
						msg(source[1],u'/me '+source[2]+rep)
						del FLL2[source[2]]
			else:
					return
		else:
			return

def bomb_leave(groupchat,nick,pr,prr):
        if nick in FLL2:
                msg(groupchat,u'Bomb Defused,'+nick+u' leaved !')
                del FLL2[nick]
                
register_leave_handler(bomb_leave)                    
register_message_handler(bomb_msg)
register_command_handler(bomb_send, 'bomb', ['fun','admin'], 15, 'hands a bomb to the competitor,if cut the wrong wire ,will kick , time 20-45 seconds', 'bomb <nick>', ['bomb kforkingfisher'])