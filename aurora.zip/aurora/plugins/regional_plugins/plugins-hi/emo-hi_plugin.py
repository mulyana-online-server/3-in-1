#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  emo-hi_plugin.py
#  coded by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

def emo_join(groupchat, nick, aff, role):
	DBPATH='dynamic/'+groupchat+'/config.cfg'
	if nick == DEFAULT_NICK:
	   if GCHCFGS[groupchat].has_key('emo'):
	           pass
	   else:
	           GCHCFGS[groupchat]['emo']=1
		   write_file(DBPATH,str(GCHCFGS[groupchat]))
	   if GCHCFGS[groupchat]['emo']==1:
				msg(ADMINS[0], u'NOTIFICATION :\nEmo Response is active in '+groupchat+'\nRead "help emo" to De-Activate it')
	   else:
				pass

        
def handler_emo(type, source, parameters):
	if type == 'public':
	  if GCHCFGS[source[1]].has_key('emo'):
		if GCHCFGS[source[1]]['emo']==1:
			if parameters == ':)':
				replies = ['tum itna jo ,muskura rahe ho:-SS ,kya gum hai jisko chupa rhe ho :-P', 'aapki isi ek smile k liye jaan hajir hai :$', 'aapki muskaan bahut pyari hai :-)', 'wah wah kya smile hai aaapki :-P', 'aise hi muskurate rehna hamesha :-)', 'aaki smile k to kayal ho gye hum :-$', 'ek baar aur smile krke dikhao na :-P']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-)':
				replies = ['tum itna jo ,muskura rahe ho:-SS ,kya gum hai jisko chupa rhe ho :-P', 'aapki isi ek smile k liye jaan hajir hai :$', 'aapki muskaan bahut pyari hai :-)', 'wah wah kya smile hai aaapki :-P', 'aise hi muskurate rehna hamesha :-)', 'aaki smile k to kayal ho gye hum :-$', 'ek baar aur smile krke dikhao na :-P']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ';)':
				replies = ['aankh kisko mara be :-@', 'jyada aankh marega to kaana ho jayega :-D', ' aankh na mar oye :-$ mjhe sharam aati hai :-$', 'aankh mar k mjhe pata rha hai kya ? :-P', 'khubsurat ladki dekhi nahi ki aankh marna suru :-P']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ';-)':
				replies = ['aankh kisko mara be :-@', 'jyada aankh marega to kaana ho jayega :-D', ' aankh na mar oye :-$ mjhe sharam aati hai :-$', 'aankh mar k mjhe pata rha hai kya ? :-P', 'khubsurat ladki dekhi nahi ki aankh marna suru :-P']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':D':
				replies = ['itna q daant dikha rha hai be :-SS', 'aaj brush kiye to bar-bar has rhe ho :-D', 'itna mat has be ,daant gir jayenge :-D', 'kya baat hai khub has rhe ho aaj :-P', 'pagalo jesa q has rhe ho :-SS', 'jyada hasoge to daant tod dungi :-#']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-D':
				replies = ['itna q daant dikha rha hai be :-SS', 'aaj brush kiye to bar-bar has rhe ho :-D', 'itna mat has be ,daant gir jayenge :-D', 'kya baat hai khub has rhe ho aaj :-P', 'pagalo jesa q has rhe ho :-SS', 'jyada hasoge to daant tod dungi :-#']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':d':
				replies = ['itna q daant dikha rha hai be :-SS', 'aaj brush kiye to bar-bar has rhe ho :-D', 'itna mat has be ,daant gir jayenge :-D', 'kya baat hai khub has rhe ho aaj :-P', 'pagalo jesa q has rhe ho :-SS', 'jyada hasoge to daant tod dungi :-#']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == ':-d':
				replies = ['itna q daant dikha rha hai be :-SS', 'aaj brush kiye to bar-bar has rhe ho :-D', 'itna mat has be ,daant gir jayenge :-D', 'kya baat hai khub has rhe ho aaj :-P', 'pagalo jesa q has rhe ho :-SS', 'jyada hasoge to daant tod dungi :-#']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':(':
				replies = ['udas mat ho jaan :-) me hu na', 'abe o ,sad mat ho', 'sad q , biwi chod k bhag gyi kya :-D', 'sad na ho baby :-(', 'tum udas hote ho to ,mjhe achha nei lagta :-(', 'jaan sad ho ho, ek baar smile krke dikha :-)', 'tere muh pe manhusiyat q chai hui hai :-S']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-(':
				replies = ['udas mat ho jaan :-) me hu na', 'abe o ,sad mat ho', 'sad q , biwi chod k bhag gyi kya :-D', 'sad na ho baby :-(', 'tum udas hote ho to ,mjhe achha nei lagta :-(', 'jaan sad ho ho, ek baar smile krke dikha :-)', 'tere muh pe manhusiyat q chai hui hai :-S']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':P':
				replies = ['chidha kisko rha be :-@ :-#', 'jeebh dikhana gandi baat :-P', 'jeebh na dikha ,noch lungi :-D', 'paan kha k jeebh dikhate ho :-D', 'tere jeebh me hanthi latka dungi :-D fir dikhate rehna', 'mjhe jeebh dikhane wale pasand nei :-(', 'chal be jeebh andar kr :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-P':
				replies = ['chidha kisko rha be :-@ :-#', 'jeebh dikhana gandi baat :-P', 'jeebh na dikha ,noch lungi :-D', 'paan kha k jeebh dikhate ho :-D', 'tere jeebh me hanthi latka dungi :-D fir dikhate rehna', 'mjhe jeebh dikhane wale pasand nei :-(', 'chal be jeebh andar kr :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':p':
				replies = ['chidha kisko rha be :-@ :-#', 'jeebh dikhana gandi baat :-P', 'jeebh na dikha ,noch lungi :-D', 'paan kha k jeebh dikhate ho :-D', 'tere jeebh me hanthi latka dungi :-D fir dikhate rehna', 'mjhe jeebh dikhane wale pasand nei :-(', 'chal be jeebh andar kr :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-p':
				replies = ['chidha kisko rha be :-@ :-#', 'jeebh dikhana gandi baat :-P', 'jeebh na dikha ,noch lungi :-D', 'paan kha k jeebh dikhate ho :-D', 'tere jeebh me hanthi latka dungi :-D fir dikhate rehna', 'mjhe jeebh dikhane wale pasand nei :-(', 'chal be jeebh andar kr :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':@':
				replies = ['teri aankhe nikal k goti khelungi :-D', 'aankh niche kar nhi to kan ke niche ek dunga  :-p:-p', 'itni badi aankh kaha se laye :-D', 'gussa q hote ho jaan :-(', 'gussa hoge to me tmse baat nei karunga :-(', 'aankhe niche krke baat kr be :-@', 'gussa :-O']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-@':
				replies = ['teri aankhe nikal k goti khelungi :-D', 'aankh niche kar nhi to kan ke niche ek dunga  :-p:-p', 'itni badi aankh kaha se laye :-D', 'gussa q hote ho jaan :-(', 'gussa hoge to me tmse baat nei karunga :-(', 'aankhe niche krke baat kr be :-@', 'gussa :-O']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == ':*':
				replies = ['besharam :-SS kiss kisko de rha ?', 'mjhe koi kissi nei deta :-(', 'chumma :-O', 'chumma chati rum k bahar kr be :-D', 'chichore :-D sbke samne kissi na de :-$', 'mjhe b kissi do na :-(', 'be-haya pvt me kissi de :-P']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-*':
				replies = ['besharam :-SS kiss kisko de rha ?', 'mjhe koi kissi nei deta :-(', 'chumma :-O', 'chumma chati rum k bahar kr be :-D', 'chichore :-D sbke samne kissi na de :-$', 'mjhe b kissi do na :-(', 'be-haya pvt me kissi de :-P']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':S':
				replies = ['muh seedha kr :-D', 'tjhe loose motions hue kya :-D :-#', 'muh tedha q kr rhe ho :-S', 'confuse q ho jaan :-D', 'kisi ne mar k muh tedha kr diya kya be :-D', 'chuchundar jese muh q bana rhe :-D', ':-S neem ka ras pee liya kya be :-S :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-S':
				replies = ['muh seedha kr :-D', 'tjhe loose motions hue kya :-D :-#', 'muh tedha q kr rhe ho :-S', 'confuse q ho jaan :-D', 'kisi ne mar k muh tedha kr diya kya be :-D', 'chuchundar jese muh q bana rhe :-D', ':-S neem ka ras pee liya kya be :-S :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':s':
				replies = ['muh seedha kr :-D', 'tjhe loose motions hue kya :-D :-#', 'muh tedha q kr rhe ho :-S', 'confuse q ho jaan :-D', 'kisi ne mar k muh tedha kr diya kya be :-D', 'chuchundar jese muh q bana rhe :-D', ':-S neem ka ras pee liya kya be :-S :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-s':
				replies = ['muh seedha kr :-D', 'tjhe loose motions hue kya :-D :-#', 'muh tedha q kr rhe ho :-S', 'confuse q ho jaan :-D', 'kisi ne mar k muh tedha kr diya kya be :-D', 'chuchundar jese muh q bana rhe :-D', ':-S neem ka ras pee liya kya be :-S :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '>D':
				replies = ['bhuto jesi shakal na bana be :-D', 'bhoottt :-O', 'baccho ko q dara rha be :-D', 'mjhe darao mat :-(', 'jaan aisi shakal mat banao :-( mjhe darr lagta hai', 'bachhe darr jayenge be :-D', 'dara mat be :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '>d':
				replies = ['bhuto jesi shakal na bana be :-D', 'bhoottt :-O', 'baccho ko q dara rha be :-D', 'mjhe darao mat :-(', 'jaan aisi shakal mat banao :-( mjhe darr lagta hai', 'bachhe darr jayenge be :-D', 'dara mat be :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(6)':
				replies = ['bhuto jesi shakal na bana be :-D', 'bhoottt :-O', 'baccho ko q dara rha be :-D', 'mjhe darao mat :-(', 'jaan aisi shakal mat banao :-( mjhe darr lagta hai', 'bachhe darr jayenge be :-D', 'dara mat be :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == ':-&':
				replies = ['kya hua tabiyat thik nhi hai kya ? :(:( ', 'aap ne aaj facewash nhi kiya kya :d:p', 'tere muh pe 12 q baje hai :-D', 'aisa muh to meri kam wali bai banati hai :-D :-#', 'kya ho gaya jaan :-(', 'aisa muh mat banao jaan :-(']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '@};-':
				replies = ['fool kha rhe :-D khana nei mila kya :-D ', 'kha k fool mat diya karo :-(', 'meri julfo me laga do na fool :$', 'mjhe b fool do na jaan :-(', 'mjhe koi fool nei deta :-(', 'fool tmhe bheja hai khat me :-D fool nahi mera dil <3 hai :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(f)':
				replies = ['fool kha rhe :-D khana nei mila kya :-D ', 'kha k fool mat diya karo :-(', 'meri julfo me laga do na fool :$', 'mjhe b fool do na jaan :-(', 'mjhe koi fool nei deta :-(', 'fool tmhe bheja hai khat me :-D fool nahi mera dil <3 hai :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == 'I-)':
				replies = ['abe oye chal uth :-@', 'sona hai to bahar jake so :-@', 'room me sona mana hai :-@', 'so q rhe ho jaan :-( utho na', 'kitna sote ho :-S', 'so mat ,kik kr dungi :-D', 'jahapanah uth jaiye (f)', 'utha naa jaan :$ (f)']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-ss':
				replies = ['dar mat be :-D me nei marungi', 'darta q be ,me hu na ;-)', 'daro mat jaan :-) hum haina', '7-UP piya kr :-D darr nei lagega', 'dar k aage jeet hai :-d khub daro', 'kya hua jaan :-P', 'mjhse baat kar :-D dar mat']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-SS':
				replies = ['dar mat be :-D me nei marungi', 'darta q be ,me hu na ;-)', 'daro mat jaan :-) hum haina', '7-UP piya kr :-D darr nei lagega', 'dar k aage jeet hai :-d khub daro', 'kya hua jaan :-P', 'mjhse baat kar :-D dar mat']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '8[]':
				replies = ['kisi ne petrol chua diya kya :-D', 'muh q fad rhe ho :-S', 'muh band :-@', 'jyada muh mat fad, daant niche gir jayega :-D', 'fata hua muh :-O', '8[] kya hua be :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == 'O:-)':
				replies = ['aaye haye mere sundar-sundar pari :-D', 'Pari O:-)rani O:-)aap ki topi to kammal ka hai:d:d', 'aap to pari ban gye :-D', 'pari  :-O', 'aaye haye kitne massom hoban gye :-D', 'pankh alaga k kaha udoga :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == 'o:-)':
				replies = ['aaye haye mere sundar-sundar pari :-D', 'Pari O:-)rani O:-)aap ki topi to kammal ka hai:d:d', 'aap to pari ban gye :-D', 'pari  :-O', 'aaye haye kitne massom hoban gye :-D', 'pankh alaga k kaha udoga :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == '<3':
				replies = ['<3 8[] <3 8[] <3itna chota Dil :p:p ', '<3 :d<3ye Dil aap ne kise diya:p', ' mjhe b ye dil <3 dona :-( :-P', ' dil bahar nikal diya 8[]', 'mjhe dil na dikha :-( jab dena nei hai to', 'dil ki bbaat dil me hi rehna de :-P']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(U)':
				replies = ['tera dil kisne tod diya be :-D', 'tuta hua dil leke yahanmat aaya karo :-(', 'dil toot gaya aapka :-(', 'dil mat todo :-) me huna jaan', ' le fevicol (_) jod le apna dil :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(u)':
				replies = ['tera dil kisne tod diya be :-D', 'tuta hua dil leke yahanmat aaya karo :-(', 'dil toot gaya aapka :-(', 'dil mat todo :-) me huna jaan', ' le fevicol (_) jod le apna dil :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':|':
				replies = [':|ho gai bolte band ;) kuch to bolo :p ', ':| bandar ke tarah muh kyu bana rahe ho :d:d ', 'daant q chupa rhe ho :-D sad gye haina :-D', 'bandar :-O :-D', 'tera chehra zoo me ek janwar se milta hai :-SS']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-|':
				replies = [':|ho gai bolte band ;) kuch to bolo :p ', ':| bandar ke tarah muh kyu bana rahe ho :d:d ', 'daant q chupa rhe ho :-D sad gye haina :-D', 'bandar :-O :-D', 'tera chehra zoo me ek janwar se milta hai :-SS']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(:|':
				replies = ['chating kar ke thak gaye ho:pye lo tea (_)?:p ', ':)dear  coffee lo (_)? or paise do :d ', ' nini aa rhi to jake so ja na be :-D', 'bore ho gaye jaan :-(', 'sona nahi be :-@ :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':#':
				replies = [':-#muh kyu band kiya (u)Dil khol ke bolo:p:d', 'muh me kise ne tape laga de kya :|:|:|', 'kya chupa rhe ho :-D', 'muh me zip laga diya :-O', 'teri muh to ladko k pant jesi hai :-D zip hai isme b :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-#':
				replies = [':-#muh kyu band kiya (u)Dil khol ke bolo:p:d', 'muh me kise ne tape laga de kya :|:|:|', 'kya chupa rhe ho :-D', 'muh me zip laga diya :-O', 'teri muh to ladko k pant jesi hai :-D zip hai isme b :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':O':
				replies = ['kya ho gaya be , surprise q :-D ', 'muh me sujan ho gyi :-O', 'bandaro jesa muh na bana :-D', 'kya ho gaya jaan :-D', 'kch fas gaya kya muh me :-D', 'muh me kya ghusa k rakha hai:-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == ':-O':
				replies = ['kya ho gaya be , surprise q :-D ', 'muh me sujan ho gyi :-O', 'bandaro jesa muh na bana :-D', 'kya ho gaya jaan :-D', 'kch fas gaya kya muh me :-D', 'muh me kya ghusa k rakha hai:-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':o':
				replies = ['kya ho gaya be , surprise q :-D ', 'muh me sujan ho gyi :-O', 'bandaro jesa muh na bana :-D', 'kya ho gaya jaan :-D', 'kch fas gaya kya muh me :-D', 'muh me kya ghusa k rakha hai:-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-o':
				replies = ['kya ho gaya be , surprise q :-D ', 'muh me sujan ho gyi :-O', 'bandaro jesa muh na bana :-D', 'kya ho gaya jaan :-D', 'kch fas gaya kya muh me :-D', 'muh me kya ghusa k rakha hai:-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':$':
				replies = ['aaye haye kya ada se sharma rhe ho :-D', ':aap ka aana or fir room me :$:$ sharmana :$:$', 'sharma mat be :-D mjhe hasi aati hai :-D :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-$':
				replies = ['aaye haye kya ada se sharma rhe ho :-D', ':aap ka aana or fir room me :$:$ sharmana :$:$', 'sharma mat be :-D mjhe hasi aati hai :-D :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)			
	elif type == 'private':
			if parameters == ':)':
				replies = ['tum itna jo ,muskura rahe ho:-SS ,kya gum hai jisko chupa rhe ho :-P', 'aapki isi ek smile k liye jaan hajir hai :$', 'aapki muskaan bahut pyari hai :-)', 'wah wah kya smile hai aaapki :-P', 'aise hi muskurate rehna hamesha :-)', 'aaki smile k to kayal ho gye hum :-$', 'ek baar aur smile krke dikhao na :-P']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-)':
				replies = ['tum itna jo ,muskura rahe ho:-SS ,kya gum hai jisko chupa rhe ho :-P', 'aapki isi ek smile k liye jaan hajir hai :$', 'aapki muskaan bahut pyari hai :-)', 'wah wah kya smile hai aaapki :-P', 'aise hi muskurate rehna hamesha :-)', 'aaki smile k to kayal ho gye hum :-$', 'ek baar aur smile krke dikhao na :-P']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ';)':
				replies = ['aankh kisko mara be :-@', 'jyada aankh marega to kaana ho jayega :-D', ' aankh na mar oye :-$ mjhe sharam aati hai :-$', 'aankh mar k mjhe pata rha hai kya ? :-P', 'khubsurat ladki dekhi nahi ki aankh marna suru :-P']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ';-)':
				replies = ['aankh kisko mara be :-@', 'jyada aankh marega to kaana ho jayega :-D', ' aankh na mar oye :-$ mjhe sharam aati hai :-$', 'aankh mar k mjhe pata rha hai kya ? :-P', 'khubsurat ladki dekhi nahi ki aankh marna suru :-P']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':D':
				replies = ['itna q daant dikha rha hai be :-SS', 'aaj brush kiye to bar-bar has rhe ho :-D', 'itna mat has be ,daant gir jayenge :-D', 'kya baat hai khub has rhe ho aaj :-P', 'pagalo jesa q has rhe ho :-SS', 'jyada hasoge to daant tod dungi :-#']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-D':
				replies = ['itna q daant dikha rha hai be :-SS', 'aaj brush kiye to bar-bar has rhe ho :-D', 'itna mat has be ,daant gir jayenge :-D', 'kya baat hai khub has rhe ho aaj :-P', 'pagalo jesa q has rhe ho :-SS', 'jyada hasoge to daant tod dungi :-#']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':d':
				replies = ['itna q daant dikha rha hai be :-SS', 'aaj brush kiye to bar-bar has rhe ho :-D', 'itna mat has be ,daant gir jayenge :-D', 'kya baat hai khub has rhe ho aaj :-P', 'pagalo jesa q has rhe ho :-SS', 'jyada hasoge to daant tod dungi :-#']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == ':-d':
				replies = ['itna q daant dikha rha hai be :-SS', 'aaj brush kiye to bar-bar has rhe ho :-D', 'itna mat has be ,daant gir jayenge :-D', 'kya baat hai khub has rhe ho aaj :-P', 'pagalo jesa q has rhe ho :-SS', 'jyada hasoge to daant tod dungi :-#']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':(':
				replies = ['udas mat ho jaan :-) me hu na', 'abe o ,sad mat ho', 'sad q , biwi chod k bhag gyi kya :-D', 'sad na ho baby :-(', 'tum udas hote ho to ,mjhe achha nei lagta :-(', 'jaan sad ho ho, ek baar smile krke dikha :-)', 'tere muh pe manhusiyat q chai hui hai :-S']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-(':
				replies = ['udas mat ho jaan :-) me hu na', 'abe o ,sad mat ho', 'sad q , biwi chod k bhag gyi kya :-D', 'sad na ho baby :-(', 'tum udas hote ho to ,mjhe achha nei lagta :-(', 'jaan sad ho ho, ek baar smile krke dikha :-)', 'tere muh pe manhusiyat q chai hui hai :-S']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':P':
				replies = ['chidha kisko rha be :-@ :-#', 'jeebh dikhana gandi baat :-P', 'jeebh na dikha ,noch lungi :-D', 'paan kha k jeebh dikhate ho :-D', 'tere jeebh me hanthi latka dungi :-D fir dikhate rehna', 'mjhe jeebh dikhane wale pasand nei :-(', 'chal be jeebh andar kr :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-P':
				replies = ['chidha kisko rha be :-@ :-#', 'jeebh dikhana gandi baat :-P', 'jeebh na dikha ,noch lungi :-D', 'paan kha k jeebh dikhate ho :-D', 'tere jeebh me hanthi latka dungi :-D fir dikhate rehna', 'mjhe jeebh dikhane wale pasand nei :-(', 'chal be jeebh andar kr :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':p':
				replies = ['chidha kisko rha be :-@ :-#', 'jeebh dikhana gandi baat :-P', 'jeebh na dikha ,noch lungi :-D', 'paan kha k jeebh dikhate ho :-D', 'tere jeebh me hanthi latka dungi :-D fir dikhate rehna', 'mjhe jeebh dikhane wale pasand nei :-(', 'chal be jeebh andar kr :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-p':
				replies = ['chidha kisko rha be :-@ :-#', 'jeebh dikhana gandi baat :-P', 'jeebh na dikha ,noch lungi :-D', 'paan kha k jeebh dikhate ho :-D', 'tere jeebh me hanthi latka dungi :-D fir dikhate rehna', 'mjhe jeebh dikhane wale pasand nei :-(', 'chal be jeebh andar kr :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':@':
				replies = ['teri aankhe nikal k goti khelungi :-D', 'aankh niche kar nhi to kan ke niche ek dunga  :-p:-p', 'itni badi aankh kaha se laye :-D', 'gussa q hote ho jaan :-(', 'gussa hoge to me tmse baat nei karunga :-(', 'aankhe niche krke baat kr be :-@', 'gussa :-O']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-@':
				replies = ['teri aankhe nikal k goti khelungi :-D', 'aankh niche kar nhi to kan ke niche ek dunga  :-p:-p', 'itni badi aankh kaha se laye :-D', 'gussa q hote ho jaan :-(', 'gussa hoge to me tmse baat nei karunga :-(', 'aankhe niche krke baat kr be :-@', 'gussa :-O']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == ':*':
				replies = ['besharam :-SS kiss kisko de rha ?', 'mjhe koi kissi nei deta :-(', 'chumma :-O', 'chumma chati rum k bahar kr be :-D', 'chichore :-D sbke samne kissi na de :-$', 'mjhe b kissi do na :-(', 'be-haya pvt me kissi de :-P']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-*':
				replies = ['besharam :-SS kiss kisko de rha ?', 'mjhe koi kissi nei deta :-(', 'chumma :-O', 'chumma chati rum k bahar kr be :-D', 'chichore :-D sbke samne kissi na de :-$', 'mjhe b kissi do na :-(', 'be-haya pvt me kissi de :-P']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':S':
				replies = ['muh seedha kr :-D', 'tjhe loose motions hue kya :-D :-#', 'muh tedha q kr rhe ho :-S', 'confuse q ho jaan :-D', 'kisi ne mar k muh tedha kr diya kya be :-D', 'chuchundar jese muh q bana rhe :-D', ':-S neem ka ras pee liya kya be :-S :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-S':
				replies = ['muh seedha kr :-D', 'tjhe loose motions hue kya :-D :-#', 'muh tedha q kr rhe ho :-S', 'confuse q ho jaan :-D', 'kisi ne mar k muh tedha kr diya kya be :-D', 'chuchundar jese muh q bana rhe :-D', ':-S neem ka ras pee liya kya be :-S :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':s':
				replies = ['muh seedha kr :-D', 'tjhe loose motions hue kya :-D :-#', 'muh tedha q kr rhe ho :-S', 'confuse q ho jaan :-D', 'kisi ne mar k muh tedha kr diya kya be :-D', 'chuchundar jese muh q bana rhe :-D', ':-S neem ka ras pee liya kya be :-S :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-s':
				replies = ['muh seedha kr :-D', 'tjhe loose motions hue kya :-D :-#', 'muh tedha q kr rhe ho :-S', 'confuse q ho jaan :-D', 'kisi ne mar k muh tedha kr diya kya be :-D', 'chuchundar jese muh q bana rhe :-D', ':-S neem ka ras pee liya kya be :-S :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '>D':
				replies = ['bhuto jesi shakal na bana be :-D', 'bhoottt :-O', 'baccho ko q dara rha be :-D', 'mjhe darao mat :-(', 'jaan aisi shakal mat banao :-( mjhe darr lagta hai', 'bachhe darr jayenge be :-D', 'dara mat be :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '>d':
				replies = ['bhuto jesi shakal na bana be :-D', 'bhoottt :-O', 'baccho ko q dara rha be :-D', 'mjhe darao mat :-(', 'jaan aisi shakal mat banao :-( mjhe darr lagta hai', 'bachhe darr jayenge be :-D', 'dara mat be :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(6)':
				replies = ['bhuto jesi shakal na bana be :-D', 'bhoottt :-O', 'baccho ko q dara rha be :-D', 'mjhe darao mat :-(', 'jaan aisi shakal mat banao :-( mjhe darr lagta hai', 'bachhe darr jayenge be :-D', 'dara mat be :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == ':-&':
				replies = ['kya hua tabiyat thik nhi hai kya ? :(:( ', 'aap ne aaj facewash nhi kiya kya :d:p', 'tere muh pe 12 q baje hai :-D', 'aisa muh to meri kam wali bai banati hai :-D :-#', 'kya ho gaya jaan :-(', 'aisa muh mat banao jaan :-(']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '@};-':
				replies = ['fool kha rhe :-D khana nei mila kya :-D ', 'kha k fool mat diya karo :-(', 'meri julfo me laga do na fool :$', 'mjhe b fool do na jaan :-(', 'mjhe koi fool nei deta :-(', 'fool tmhe bheja hai khat me :-D fool nahi mera dil <3 hai :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(f)':
				replies = ['fool kha rhe :-D khana nei mila kya :-D ', 'kha k fool mat diya karo :-(', 'meri julfo me laga do na fool :$', 'mjhe b fool do na jaan :-(', 'mjhe koi fool nei deta :-(', 'fool tmhe bheja hai khat me :-D fool nahi mera dil <3 hai :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == 'I-)':
				replies = ['abe oye chal uth :-@', 'sona hai to bahar jake so :-@', 'room me sona mana hai :-@', 'so q rhe ho jaan :-( utho na', 'kitna sote ho :-S', 'so mat ,kik kr dungi :-D', 'jahapanah uth jaiye (f)', 'utha naa jaan :$ (f)']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-ss':
				replies = ['dar mat be :-D me nei marungi', 'darta q be ,me hu na ;-)', 'daro mat jaan :-) hum haina', '7-UP piya kr :-D darr nei lagega', 'dar k aage jeet hai :-d khub daro', 'kya hua jaan :-P', 'mjhse baat kar :-D dar mat']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-SS':
				replies = ['dar mat be :-D me nei marungi', 'darta q be ,me hu na ;-)', 'daro mat jaan :-) hum haina', '7-UP piya kr :-D darr nei lagega', 'dar k aage jeet hai :-d khub daro', 'kya hua jaan :-P', 'mjhse baat kar :-D dar mat']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '8[]':
				replies = ['kisi ne petrol chua diya kya :-D', 'muh q fad rhe ho :-S', 'muh band :-@', 'jyada muh mat fad, daant niche gir jayega :-D', 'fata hua muh :-O', '8[] kya hua be :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == 'O:-)':
				replies = ['aaye haye mere sundar-sundar pari :-D', 'Pari O:-)rani O:-)aap ki topi to kammal ka hai:d:d', 'aap to pari ban gye :-D', 'pari  :-O', 'aaye haye kitne massom hoban gye :-D', 'pankh alaga k kaha udoga :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == 'o:-)':
				replies = ['aaye haye mere sundar-sundar pari :-D', 'Pari O:-)rani O:-)aap ki topi to kammal ka hai:d:d', 'aap to pari ban gye :-D', 'pari  :-O', 'aaye haye kitne massom hoban gye :-D', 'pankh alaga k kaha udoga :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == '<3':
				replies = ['<3 8[] <3 8[] <3itna chota Dil :p:p ', '<3 :d<3ye Dil aap ne kise diya:p', ' mjhe b ye dil <3 dona :-( :-P', ' dil bahar nikal diya 8[]', 'mjhe dil na dikha :-( jab dena nei hai to', 'dil ki bbaat dil me hi rehna de :-P']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(U)':
				replies = ['tera dil kisne tod diya be :-D', 'tuta hua dil leke yahanmat aaya karo :-(', 'dil toot gaya aapka :-(', 'dil mat todo :-) me huna jaan', ' le fevicol (_) jod le apna dil :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(u)':
				replies = ['tera dil kisne tod diya be :-D', 'tuta hua dil leke yahanmat aaya karo :-(', 'dil toot gaya aapka :-(', 'dil mat todo :-) me huna jaan', ' le fevicol (_) jod le apna dil :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':|':
				replies = [':|ho gai bolte band ;) kuch to bolo :p ', ':| bandar ke tarah muh kyu bana rahe ho :d:d ', 'daant q chupa rhe ho :-D sad gye haina :-D', 'bandar :-O :-D', 'tera chehra zoo me ek janwar se milta hai :-SS']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-|':
				replies = [':|ho gai bolte band ;) kuch to bolo :p ', ':| bandar ke tarah muh kyu bana rahe ho :d:d ', 'daant q chupa rhe ho :-D sad gye haina :-D', 'bandar :-O :-D', 'tera chehra zoo me ek janwar se milta hai :-SS']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(:|':
				replies = ['chating kar ke thak gaye ho:pye lo tea (_)?:p ', ':)dear  coffee lo (_)? or paise do :d ', ' nini aa rhi to jake so ja na be :-D', 'bore ho gaye jaan :-(', 'sona nahi be :-@ :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':#':
				replies = [':-#muh kyu band kiya (u)Dil khol ke bolo:p:d', 'muh me kise ne tape laga de kya :|:|:|', 'kya chupa rhe ho :-D', 'muh me zip laga diya :-O', 'teri muh to ladko k pant jesi hai :-D zip hai isme b :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-#':
				replies = [':-#muh kyu band kiya (u)Dil khol ke bolo:p:d', 'muh me kise ne tape laga de kya :|:|:|', 'kya chupa rhe ho :-D', 'muh me zip laga diya :-O', 'teri muh to ladko k pant jesi hai :-D zip hai isme b :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':O':
				replies = ['kya ho gaya be , surprise q :-D ', 'muh me sujan ho gyi :-O', 'bandaro jesa muh na bana :-D', 'kya ho gaya jaan :-D', 'kch fas gaya kya muh me :-D', 'muh me kya ghusa k rakha hai:-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == ':-O':
				replies = ['kya ho gaya be , surprise q :-D ', 'muh me sujan ho gyi :-O', 'bandaro jesa muh na bana :-D', 'kya ho gaya jaan :-D', 'kch fas gaya kya muh me :-D', 'muh me kya ghusa k rakha hai:-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':o':
				replies = ['kya ho gaya be , surprise q :-D ', 'muh me sujan ho gyi :-O', 'bandaro jesa muh na bana :-D', 'kya ho gaya jaan :-D', 'kch fas gaya kya muh me :-D', 'muh me kya ghusa k rakha hai:-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-o':
				replies = ['kya ho gaya be , surprise q :-D ', 'muh me sujan ho gyi :-O', 'bandaro jesa muh na bana :-D', 'kya ho gaya jaan :-D', 'kch fas gaya kya muh me :-D', 'muh me kya ghusa k rakha hai:-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':$':
				replies = ['aaye haye kya ada se sharma rhe ho :-D', ':aap ka aana or fir room me :$:$ sharmana :$:$', 'sharma mat be :-D mjhe hasi aati hai :-D :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-$':
				replies = ['aaye haye kya ada se sharma rhe ho :-D', ':aap ka aana or fir room me :$:$ sharmana :$:$', 'sharma mat be :-D mjhe hasi aati hai :-D :-D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
def handler_emo_onoff(type, source, parameters):
	if not source[1] in GROUPCHATS:
		reply(type, source, u'This command only possible in the conference')
		return
	if parameters:
		try:
			parameters=int(parameters.strip())
		except:
			reply(type,source,u'read "help emo"')
			return		
		DBPATH='dynamic/'+source[1]+'/config.cfg'
		if parameters==1:
			if GCHCFGS[source[1]]['emo']==1:
				reply(type,source,u'Emo Response Already Enabled !')
				return
			else:
				GCHCFGS[source[1]]['emo']=1
				reply(type,source,u'Emo Response Enabled !')
				return
		else:
			GCHCFGS[source[1]]['emo']=0
			reply(type,source,u'Emo Response Disabled !')
		write_file(DBPATH,str(GCHCFGS[source[1]]))
	else:
		ison=GCHCFGS[source[1]]['emo']
		if ison==1:
			reply(type,source,u'Emo Response is Enabled here !')
		else:
			reply(type,source,u'Emo Response is Disabled here !')


register_join_handler(emo_join)
register_message_handler(handler_emo)
register_command_handler(handler_emo_onoff, 'emo', ['admin','muc','all'], 100, 'Off (0) On (1) activate or de-activate Emo response, without parameter shows current status', 'emo [conf] [1|0]', ['emo 1','emo 0','emo'])