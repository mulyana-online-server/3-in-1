#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  vartalap-ml_plugin.py
#  coded by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

def handler_bot_(type, source, parameters):
       replies = [u'hii:):)', u'ha parayu njan ivdund:):)', u'parayu ninakkenthu patti :)(:|', u'ya m here :) ', u'enne shalyam cheyyallu I-) (:| ']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_hi_(type, source, parameters):
        replies = [u'Hlew :-):-)', u'hi nee avdundoo  :-):-)', u'hhlllllllllllooooooo :D', u'hhiiiiiiiii :D:P' ]
        balas = random.choice(replies)
        if type == 'public':
                if source[1]:
                        reply(type, source, balas)
        elif type == 'private':
                reply(type, source, balas)
				
def handler_salam_(type, source, parameters):
        replies = [u':-) WALAIKUM ASsalam:)', u'walaikumsalam :-):-)', u'wa\' alaikumsalam :)(f)', u'wa\' alaikumsalam :-)(f)', u'ws :) (f)']
        balas = random.choice(replies)
        if type == 'public':
                if source[1]:
                        reply(type, source, balas)
        elif type == 'private':
                reply(type, source, balas)


def handler_leaving_(type, source, parameters):
        replies = [u'njangal ninne miss cheyyum :D:P ', u'pinne kanamm :P bye', u'ok ippol pokuu :(:P', u'enne kerala! roomil thanichakkalluu:( :D', u' nee inuyum varumo kerala! ilum kerala. ilum ? :)']
        balas = random.choice(replies)
        if type == 'public':
                if source[1]:
                        reply(type, source, balas)
        elif type == 'private':
                reply(type, source, balas)

def handler_thanks_(type, source, parameters):
       replies = [u'my pleasure :):)', u' pleasure is all thebluesteye nd r()$a :)']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_gali_(type, source, parameters):
       replies = [u':@ chetha vakku parayaruthu r()$a ninne therippikkum :@ ', u':@u dont have manners? :@ :@ ', u' if u abuse 1 more time i will kick u :D']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_fine_(type, source, parameters):
       replies = [u'enikkum sugam anuu:d :p ', u' m fit nd fine u tell? ;) ']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_chup_(type, source, parameters):
       replies = [u'u shut up :p:D ', u'shut ur mouth first:D ']
       balas = random.choice(replies)
       if type == 'public': 
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_song_(type, source, parameters):
       replies = [u' r()$a ninakkuvendi padum:)' ]
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)


def handler_ac_(type, source, parameters):
        if not parameters:
                reply(type, source, u'AC ON/OFF')
        if parameters:
                if parameters=='on':
                        msg(source[1],u'Activating K-AC™...')
			time.sleep(10.0)
                        msg(source[1],u'k-AC™ Activated \nenjoy supercool Environment')
                elif parameters=='off':
                        msg(source[1],u'De-Activating K-AC™...')
			time.sleep(10.0)
                        msg(source[1],u'K-AC™ De-Activated')
                else:
                        reply(type,source,u'contact engineer !!!')


def handler_music_(type, source, parameters):
        if not parameters:
                reply(type, source, u'MUSIC ON/OFF')
        if parameters:
                if parameters=='on':
                        msg(source[1],u'Activating K-blaster™...')
			time.sleep(10.0)
                        msg(source[1],u'K-blaster™ Activated \nEnjoy 18,000 watt Woofers with Dolby™ Digital sound')
                elif parameters=='off':
                        msg(source[1],u'De-Activating K-blaster™...')
			time.sleep(10.0)
                        msg(source[1],u'K-blaster™ De-Activated')
                else:
                        reply(type,source,u'contact engineer !!!')


def handler_dance_(type, source, parameters):
       replies = [u'\n\:-D/ \n<:-D/ \n\:-P> \n\;-)> \n<:-D> \nkaisa laga mera chamiya dance?:-D', u'\n\:-P> \n\:-D/ \n\:-P> \n<:-D/ \n<:-D> \nmunni badnam hui ,darling tere liye..:$']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)


def handler_lights_(type, source, parameters):
        if not parameters:
                reply(type, source, u'LIGHTS ON/OFF')
        if parameters:
                if parameters=='on':
                        msg(source[1],u'LIGHTS ON')
                elif parameters=='off':
                        msg(source[1],u'LIGHTS OFF')
                else:
                        msg(source[1],u'contact engineer !!!')

def handler_help_(type, source, parameters):
       replies = [u'i can reply to these words :- ac,music,lights,fact,song,maker,joke,english,kf,help,shayari,sher']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)




register_command_handler(handler_bot_, 'bot', ['new'], 0, '', '', [''])
register_command_handler(handler_leaving_, 'brb', ['new'], 0, '', '', [''])
register_command_handler(handler_leaving_, 'bye', ['new'], 0, '', '', [''])
register_command_handler(handler_leaving_, 'byee', ['new'], 0, '', '', [''])
register_command_handler(handler_leaving_, 'tc', ['new'], 0, '', '', [''])
register_command_handler(handler_leaving_, 'gn', ['new'], 0, '', '', [''])
register_command_handler(handler_leaving_, 'gn8', ['new'], 0, '', '', [''])
register_command_handler(handler_leaving_, 'g98', ['new'], 0, '', '', [''])
register_command_handler(handler_leaving_, 'sd', ['new'], 0, '', '', [''])
register_command_handler(handler_leaving_, 'ah', ['new'], 0, '', '', [''])
register_command_handler(handler_leaving_, 'cya', ['new'], 0, '', '', [''])
register_command_handler(handler_hi_, 'hi', ['new'], 0, '', '', [''])
register_command_handler(handler_hi_, 'hii', ['new'], 0, '', '', [''])
register_command_handler(handler_hi_, 'hii1', ['new'], 0, '', '', [''])
register_command_handler(handler_hi_, 'hello', ['new'], 0, '', '', [''])
register_command_handler(handler_hi_, 'helo', ['new'], 0, '', '', [''])
register_command_handler(handler_hi_, 'halo', ['new'], 0, '', '', [''])
register_command_handler(handler_hi_, 'hey', ['new'], 0, '', '', [''])
register_command_handler(handler_hi_, 'heya', ['new'], 0, '', '', [''])
register_command_handler(handler_hi_, 'hiya', ['new'], 0, '', '', [''])
register_command_handler(handler_salam_, 'salam', ['new'], 0, '', '', [''])
register_command_handler(handler_salam_, 'salaam', ['new'], 0, '', '', [''])
register_command_handler(handler_salam_, 'assalaam', ['new'], 0, '', '', [''])
register_command_handler(handler_salam_, 'asalaam', ['new'], 0, '', '', [''])
register_command_handler(handler_salam_, 'asalam', ['new'], 0, '', '', [''])
register_command_handler(handler_salam_, 'assalam', ['new'], 0, '', '', [''])
register_command_handler(handler_salam_, 'assalaamwalaekum', ['new'], 0, '', '', [''])
register_command_handler(handler_salam_, 'asalaamwalaekum', ['new'], 0, '', '', [''])
register_command_handler(handler_salam_, 'assalaamwalaikum', ['new'], 0, '', '', [''])
register_command_handler(handler_salam_, 'asalaamwalaikum', ['new'], 0, '', '', [''])
register_command_handler(handler_thanks_, 'thanx', ['new'], 0,'', '', [''])
register_command_handler(handler_thanks_, 'thx', ['new'], 0, '', '', [''])
register_command_handler(handler_thanks_, 'thanks', ['new'], 0, '', '', [''])
register_command_handler(handler_thanks_, 'ty', ['new'], 0, '', '', [''])
register_command_handler(handler_thanks_, 'tx', ['new'], 0, '', '', [''])
register_command_handler(handler_thanks_, 'tq', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'madarchod', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'kutiya', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'gandu', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'gaandu', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'chutiya', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'chutiye', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'chootiya', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'chootiye', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'randi', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'raand', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'rand', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'bhosda', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'bhosdi', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'gand', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'gaand', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'chut', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'choot', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'sali', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'behanchod', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'land', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'lund', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'lauda', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'laude', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'loda', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'lode', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'chinal', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'harami', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'chodu', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'fudu', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'fudi', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'fuddu', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'fuddi', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'fuck', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'fuckoff', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'asshole', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'fucker', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'pussy', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'boobs', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'gay', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'motherfuckker', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'dick', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'pens', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'vegina', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'clitoris', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'moron', ['new'], 0, '', '', [''])
register_command_handler(handler_gali_, 'hore', ['new'], 0, '', '', [''])
register_command_handler(handler_fine_, '59', ['new'], 0, '', '', [''])
register_command_handler(handler_fine_, 'f9', ['new'], 0, '', '', [''])
register_command_handler(handler_fine_, 'fine', ['new'], 0, '', '', [''])
register_command_handler(handler_fine_, 'fn', ['new'], 0, '', '', [''])
register_command_handler(handler_fine_, '5n', ['new'], 0, '', '', [''])
register_command_handler(handler_fine_, 'good', ['new'], 0, '', '', [''])
register_command_handler(handler_fine_, 'gud', ['new'], 0, '', '', [''])
register_command_handler(handler_fine_, 'mast', ['new'], 0, '', '', [''])
register_command_handler(handler_fine_, 'good', ['new'], 0, '', '', [''])
register_command_handler(handler_fine_, 'gud', ['new'], 0, '', '', [''])
register_command_handler(handler_fine_, 'mast', ['new'], 0, '', '', [''])
register_command_handler(handler_chup_, 'chup', ['new'], 0, '', '', [''])
register_command_handler(handler_song_, 'song', ['new'], 0, '', '', [''])
register_command_handler(handler_song_, 'gana', ['new'], 0, '', '', [''])
register_command_handler(handler_song_, 'gaana', ['new'], 0, '', '', [''])
register_command_handler(handler_ac_, 'ac', ['new'], 0, '', '', [''])
register_command_handler(handler_music_, 'music', ['new'], 0, '', '', [''])
register_command_handler(handler_dance_, 'dance', ['new'], 0, '', '', [''])
register_command_handler(handler_dance_, 'nach', ['new'], 0, '', '', [''])
register_command_handler(handler_dance_, 'naach', ['new'], 0, '', '', [''])
register_command_handler(handler_lights_, 'lights', ['new'], 0, '', '', [''])
register_command_handler(handler_help_, 'help', ['new'], 0, '', '', [''])