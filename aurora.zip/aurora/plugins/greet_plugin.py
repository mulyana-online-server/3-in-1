#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  greet_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################


def greetz_work(jid='',greet='',gch=''):
	DBPATH='dynamic/'+gch+'/greetz.txt'
	if check_file(gch,'greetz.txt'):
		greetzdb = eval(read_file(DBPATH))
		if jid and greet:
			if not jid in greetzdb.keys():
				greetzdb[jid]=jid
				greetzdb[jid]=greet
				write_file(DBPATH, str(greetzdb))
				return 1
			else:
				greetzdb[jid]=greet
				write_file(DBPATH, str(greetzdb))
				return 1
		elif jid:
			if jid in greetzdb.keys():
				del greetzdb[jid]
				write_file(DBPATH, str(greetzdb))
				return 1
			return 0
		else:
			return 0


def handler_greet(type,source,parameters):
	if not parameters:
		reply(type, source, u'aur?')
		return
	parameters=parameters.strip()
	rawgreet = string.split(parameters, '=', 1)
	if not len(rawgreet)==2:
		reply(type, source, u'wo kya tha ?')
		return
	greet=rawgreet[1].strip()
	nicks=GROUPCHATS[source[1]].keys()
	if rawgreet[0].count('@')>0 and rawgreet[0].count('.')>0:
		jid=rawgreet[0]
	elif rawgreet[0] in nicks:
		jid=get_true_jid(source[1]+'/'+rawgreet[0])
	else:
		reply(type, source, u'was he here? :-O')
		return
	if not greet:
		answ=greetz_work(jid,gch=source[1])
		if answ:
			reply(type, source, u'killed')
			get_greetz(gch=source[1])
			return
		else:
			reply(type, source, u'wo kaun hai ?')
			return
	answ=greetz_work(jid,greet,source[1])
	if answ:
		reply(type, source, u'ok')
		get_greetz(gch=source[1])
	else:
		reply(type, source, u'wo kya tha ?')
		
			
def atjoin_greetz(groupchat, nick, aff, role):
	if time.time()-INFO['start']>10:
	 jid=get_true_jid(groupchat+'/'+nick)
	 if groupchat in GREETZ.keys():
	 	if jid in GREETZ[groupchat]:
	 		msg(groupchat, nick+'> '+GREETZ[groupchat][jid])
	 		
	 		
def get_greetz(gch):
	grtfile='dynamic/'+gch+'/greetz.txt'
	try:
		grt = eval(read_file(grtfile))
		GREETZ[gch]=grt
	except:
		pass
			
register_command_handler(handler_greet, 'greet', ['muc','admin','all'], 20, 'Adds greeting for certain a nick or jid.', 'greet <nick/jid', ['greet guy=something','greet guy@server.tld=something'])
register_join_handler(atjoin_greetz)

register_stage1_init(get_greetz)
