#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  profile_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################


features ={'FORM_TYPE':'FORM_TYPE', 'status': 'status', 'nickname':'nickname', 'street':'street', 'locality':'locality', 'region':'region', 'country':'country', 'gender':'gender', 'birth_year':'birth', 'birth_month':'birth', 'birth_dayofmonth':'birth', 'username':'user'}

def handler_profile(type, source, parameters):
	jid = parameters
	if parameters.split():
		iq = xmpp.Iq('get')
		iq.setID('ulti_profile')
		iq.setTo(jid+'@nimbuzz.com')
		query = xmpp.Node('query')
		query.setNamespace('http://jabber.org/protocol/profile')
		iq.addChild(node=query)
		JCON.SendAndCallForResponse(iq, handler_profile_answ, {'type': type, 'source': source})

def handler_profile_answ(coze, res, type, source):
	if res:
		if res.getType() == 'result':
			aa=res.getTag('profile')
			if aa==None:
				print 'error'
			else:
				m=aa.getTag('x')
				if m:
					bb=m.getTags('field')
					if bb:
						for g in bb:
							if g.getAttr('var') == 'nickname':
								ww=g.getChildren()
								if ww:
									for k in ww:
										if k.getName() == 'value':
											reply(type, source, u'Nickname: '+k.getData())
							if g.getAttr('var') == 'status':
								ww=g.getChildren()
								if ww:
									for k in ww:
										if k.getName() == 'value':
											reply(type, source, u'Status: '+k.getData())
					else:
						print 'error2'
				else:
					print 'error1' 
		elif res.getType() == 'error':
			reply(type, source, res.getError())

register_command_handler(handler_profile, 'profile', ['info','muc','all'], 0, 'Shows the status and nickname of the JID', 'profile <jid>', ['profile kforkingfisher'])