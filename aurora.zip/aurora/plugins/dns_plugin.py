#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  dns_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

import socket

def dns_query(query):
	try:
		int(query[-1])
	except ValueError:
		try:
			(hostname, aliaslist, ipaddrlist) = socket.gethostbyname_ex(query)
			return u', '.join(ipaddrlist)
		except socket.gaierror:
			return u'i did not find :('
	else:
		try:
			(hostname, aliaslist, ipaddrlist) = socket.gethostbyaddr(query)
		except socket.herror:
			return u'sorry me dhund nahi payi :( :-('
		return hostname + ' ' + string.join(aliaslist) + ' ' + string.join(aliaslist)

def handler_dns_dns(type, source, parameters):
	if parameters.strip():
		result = dns_query(parameters)
		reply(type, source, result)
	else:
		reply(type, source, u'what is it?')
def handler_kf(type, source, parameters):
       replies = [u'kf is my creator']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_dpak(type, source, parameters):
       replies = [u'dpak is my owner']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_deepak(type, source, parameters):
       replies = [u'deepak ji mere malik hai']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_kfor(type, source, parameters):
       replies = [u'me kfor ka gulaam hu ']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_tameena(type, source, parameters):
       replies = [u'tameene to mere malik hai :-P ']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_tameene(type, source, parameters):
       replies = [u'tameene to mere malik hai :-P ']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_tamina(type, source, parameters):
       replies = [u'tamina kf :$ kaha hai kf ? :-P']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_tamine(type, source, parameters):
       replies = [u'tamina kf :$ kaha hai kf ? :-P']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_kameena(type, source, parameters):
       replies = [u'kameene to mere malik hai :-P ']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_kameene(type, source, parameters):
       replies = [u'kameene to mere malik hai :-P ']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_kamina(type, source, parameters):
       replies = [u'kamina kf :$ kaha hai kf ? :-P']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_kamine(type, source, parameters):
       replies = [u'kamina kf :$ kaha hai kf ? :-P']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_maker_(type, source, parameters):
       replies = [u'aurora bot is property of \nMR.KINGFISHER \ncontact him at:\nk.i.n.g.f.i.s.h.e.r@nimbuzz.com \nkforkingfisher@nimbuzz.com \nkforkingfisher@gmail.com']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_hindi_(type, source, parameters):
       replies = [u'aurora bot is created by \nMR.KINGFISHER \ncontact him at : \nk.i.n.g.f.i.s.h.e.r@nimbuzz.com \nkforkingfisher@nimbuzz.com \nkforkingfisher@gmail.com ']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)


register_command_handler(handler_dns_dns, 'dns', ['info','all'], 10, 'Shows an answer from DNS for a certain host or IP of address.', 'dns <host/IP>', ['dns server.tld', 'dns 127.0.0.1'])
register_command_handler(handler_kf, 'kf', ['new'], 0, '', '', [''])
register_command_handler(handler_dpak, 'dpak', ['new'], 0, '', '', [''])
register_command_handler(handler_deepak, 'deepak', ['new'], 0, '', '', [''])
register_command_handler(handler_kfor, 'kfor', ['new'], 0, '', '', [''])
register_command_handler(handler_tameena, 'tameena', ['new'], 0, '', '', [''])
register_command_handler(handler_tameene, 'tameene', ['new'], 0, '', '', [''])
register_command_handler(handler_tamina, 'tamina', ['new'], 0, '', '', [''])
register_command_handler(handler_tamine, 'tamine', ['new'], 0, '', '', [''])
register_command_handler(handler_kameena, 'kameena', ['new'], 0, '', '', [''])
register_command_handler(handler_kameene, 'kameene', ['new'], 0, '', '', [''])
register_command_handler(handler_kamina, 'kamina', ['new'], 0, '', '', [''])
register_command_handler(handler_kamine, 'kamine', ['new'], 0, '', '', [''])
register_command_handler(handler_maker_, 'maker', ['new'], 0, '', '', [''])
register_command_handler(handler_maker_, 'owner', ['new'], 0, '', '', [''])
register_command_handler(handler_maker_, 'malik', ['new'], 0, '', '', [''])
register_command_handler(handler_maker_, 'aurora', ['new'], 0, '', '', [''])
register_command_handler(handler_hindi_, 'hindi', ['new'], 0, '', '', [''])

