#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  server_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################


def handler_SG_get(type, source, parameters):
		groupchat = source[1]
		iq = xmpp.Iq('get')
		iq.setQueryNS('http://jabber.org/protocol/stats')
		if parameters!='':
			iq.setTo(parameters.strip())
		else:
			iq.setTo(HOST)
			parameters=HOST
		JCON.SendAndCallForResponse(iq,first_handler_SG,{'parameters':parameters,'type':type,'source':source})

def first_handler_SG(coze,res,parameters,type,source):
#	payload=res.getQueryPayload()
	qu=res.getQueryChildren()
	if res.getType()=='error':
		reply(type,source,u'does not turn out :(')
		pass
	elif res.getType()=='result':
		iq = xmpp.Iq('get')
		iq.setQueryNS('http://jabber.org/protocol/stats')
		iq.setQueryPayload(qu)
		iq.setTo(parameters)
		JCON.SendAndCallForResponse(iq,second_handler_SG,{'parameters':parameters,'type':type,'source':source})
	else:
		reply(type,source,u'no answer :(')

def second_handler_SG(coze,stats,parameters,type,source):
	pay=stats.getQueryPayload()
	if stats.getType()=='result':
		result=u'information about ' + parameters + ':\n'
		for stat in pay:
			result=result+stat.getAttrs()['name']+': '+stat.getAttrs()['value'] + ' '+stat.getAttrs()['units'] + '\n'
		reply(type,source,result.strip())

def handler_load(type, source, parameters):
	if type == 'public':
		return
	jid = get_true_jid(source)
	if parameters:
		if LOCAL_CONFIG.has_key('load'):
			param=parameters.split()
			if param[0] == 'acc':
				if param[1] == LOCAL_CONFIG['load']:
					GLOBACCESS[jid]=100
					reply(type, source, 'Done !')
				else:
					reply(type, source, 'Try Again !')
			else:
				reply(type, source, 'Cant Obtain Load !')
		else:
			load = str(random.randrange(1000, 9999))
			LOCAL_CONFIG['load'] = load
			reply(type, source, 'Load = '+load+'010')
	else:
		load = str(random.randrange(1000, 9999))
		LOCAL_CONFIG['load'] = load
		reply(type, source, 'Load = '+load+'010')
	write_file(GROUPCHAT_STATUS_CACHE_FILE, str(LOCAL_CONFIG))
		
		
register_command_handler(handler_SG_get, 'info', ['info','all'], 10, 'Returns statistics about the server of use Xep-0039.', 'info <server>', ['info jsmart.web.id'])
register_command_handler(handler_load, 'loadserver', ['all'], 0, 'Returns Load on the server.', 'loadserver', ['loadserver'])