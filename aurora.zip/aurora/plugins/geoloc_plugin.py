#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  geoloc_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

geoloc_pending=[]
def handler_geoloc(type, source, parameters):
        iq = xmpp.Iq('get')
	iq.setID('id')
	iq.setTo(parameters)
        query = xmpp.Node('geoloc')
	query.setNamespace('http://jabber.org/protocol/geoloc')
	iq.addChild(node=query)
	JCON.SendAndCallForResponse(iq, handler_geoloc_answ, {'type': type, 'source': source})
	return

def handler_geoloc_answ(coze, res, type, source):
        time.sleep(7)
        
	if res:
                
		if res.getType() == 'result':
                        print 'yes'

                        aa=res.getTag('geoloc')
                        if aa:
                                bb=aa.getChildren()
                                
                                if bb:
                                        print 'yes1'
                                        for x in bb:
                                                
                                                if x.getName() == 'lat':
                                                        
                                                        lat=x.getData()
                                                        print lat
                                                elif x.getName() == 'lon':
                                                        lon=x.getData()
                                                        print lon
                                                elif x.getName() == 'accuracy':
                                                        accuracy=x.getData()
                                                        print accuracy

                                        reply(type, source, u'http://services.nimbuzz.com/map?lt='+lat+u'&lg='+lon+u'&a='+accuracy+u'&w=204&h=204&z=1')	

                                        
                               

	if not res:
                
                reply(type, source, u'error')
                        
















register_command_handler(handler_geoloc, 'geoloc', ['info','muc','all'], 0, 'Shows a link to a map of the location of the given JID (must be on bot list and location sharing enabled)', 'geoloc', ['geoloc'])