#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  tv_plugin.py
#  coded by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

CAT = [u'ENTERTAINMENT', u'MUSIC', u'NEWS', u'SCIENCE', u'MOVIES', u'KIDS', u'LIFESTYLES', u'DEVOTIONAL']
ENTERTAINMENT = [u'STARPLUS',u'ZOOM TV',u'SONY TV',u'STAR ONE',u'SAB TV',u'STAR UTSAV',u'NDTV GOODTIMES',u'UTV STARS',u'UTV BINDAS']
MUSIC = [u'CHANNEL V',u'MUSIC INDIA',u'9XM',u'B4U MUSIC',u'ZING MUSIC',u'BOLLYWOOD NIRWANA',u'TASHAN',u'9XM JHAKKAS',u'MIAMI MUSIC TV',u'CHANNEL S BANGLA',u'VIVA MUSIC TV',u'4 MUSIC TV',u'SANGEET BHOJPURI']
NEWS = [u'AAJTAK',u'HEADLINES TODAY',u'NDTV',u'NDTV 24X7',u'NDTV PROFIT',u'TIMES NOW',u'IBN 7',u'IBN LOKMAT',u'CNN IBN',u'CNBC AAWAZ',u'CNBC TV18',u'BLOOMBERG TV',u'INDIA TV',u'CNN INTERNATIONAL',u'SUWARNA NEWS',u'RT NEWS',u'TV9',u'AAJTAK TEZ',u'DELHI AAJTAK',u'DD NEWS',u'PTC NEWS',u'NEWS 9']
SCIENCE = [u'HISTORY CHANNEL',u'DISCOVERY CHANNEL',u'DISCOVERY SCIENCE',u'DISCOVERY TURBO',u'ANIMAL PLANET']
MOVIES = [u'UTV MOVIES',u'B4U MOVIES',u'BOLLYWOOD ACTION',u'BOLLYWOOD MOVIES N MUSIC',u'MAA MOVIE']
KIDS = [u'CARTOON NETWORK',u'POGO',u'DISNEY HINDI',u'DISNEY ENGLISH']
LIFESTYLE = [u'FASHION TV',u'TRAVEL XP',u'TLC']
DEVOTIONAL = [u'AASHTHA TV',u'SHRADDHA TV']
fllcat = '0'
fllen = '0'
fllmu = '0'
fllnw = '0'
fllsc = '0'
fllmov = '0'
fllkid = '0'
flllyf = '0'
flldev = '0'

def handler_tv(type, source, parameters):
	global fllcat
	global fllen
	global fllmu
	global fllnw
	global fllsc
	global fllmov
	global fllkid
	global flllyf
	global flldev
	reset = '\nMenu will reset in next 30 seconds'
	answer = u"TV CATAGORIES : FROM 1 TO 8\n"
	if type == 'public':
			if not parameters:
					reply(type, source,u'Send "TV" in Private To View TV MENU !!')
					pass
			else:
					pass
	elif type == 'private':
			if not parameters:
				if fllcat == '0':
					for a, b in enumerate(CAT):
						answer += u"%i. %s, " % (a + 1, b)
					reply(type, source, answer.encode("utf-8")+'\nsend catagory number from 1 to 8 to view channels list.'+reset)
					fllcat = source[2]
					time.sleep(30.0)
					fllcat = '0'
					pass
				else:
					reply(type, source,u'WAIT for a while !!')
			else:
					pass
					
def catagory_msg(type,source,parameters):
	global fllcat
	global fllen
	global fllmu
	global fllnw
	global fllsc
	global fllmov
	global fllkid
	global flllyf
	global flldev
	reset = '\nMenu will reset in next 30 seconds'
	if fllcat == source[2]:
		if parameters=='1':
					answer = u"ENTERTAINMENT CHANNELS : FROM 1 TO 9\n"
					for a, b in enumerate(ENTERTAINMENT):
						answer += u"%i. %s, " % (a + 1, b)
					reply(type, source, answer.encode("utf-8")+'\nsend channel number from 1 to 9 to view RTSP LINKS.'+reset)
					fllcat = '0'
					time.sleep(1.0)
					fllen = source[2]
					time.sleep(30.0)
					fllen = '0'
					pass
		elif parameters=='2':
					answer = u"MUSIC CHANNELS : FROM 1 TO 13\n"
					for a, b in enumerate(MUSIC):
						answer += u"%i. %s, " % (a + 1, b)
					reply(type, source, answer.encode("utf-8")+'\nsend channel number from 1 to 13 to view RTSP LINKS.'+reset)
					fllcat = '0'
					time.sleep(1.0)
					fllmu = source[2]
					time.sleep(30.0)
					fllmu = '0'
					pass
		elif parameters=='3':
					answer = u"NEWS CHANNELS : FROM 1 TO 22\n"
					for a, b in enumerate(NEWS):
						answer += u"%i. %s, " % (a + 1, b)
					reply(type, source, answer.encode("utf-8")+'\nsend channel number from 1 to 22 to view RTSP LINKS.'+reset)
					fllcat = '0'
					time.sleep(1.0)
					fllnw = source[2]
					time.sleep(30.0)
					fllnw = '0'
					pass
		elif parameters=='4':
					answer = u"SCIENCE CHANNELS : FROM 1 TO 5\n"
					for a, b in enumerate(SCIENCE):
						answer += u"%i. %s, " % (a + 1, b)
					reply(type, source, answer.encode("utf-8")+'\nsend channel number from 1 to 5 to view RTSP LINKS.'+reset)
					fllcat = '0'
					time.sleep(1.0)
					fllsc = source[2]
					time.sleep(30.0)
					fllsc = '0'
					pass
		elif parameters=='5':
					answer = u"MOVIES CHANNELS : FROM 1 TO 5\n"
					for a, b in enumerate(MOVIES):
						answer += u"%i. %s, " % (a + 1, b)
					reply(type, source, answer.encode("utf-8")+'\nsend channel number from 1 to 5 to view RTSP LINKS.'+reset)
					fllcat = '0'
					time.sleep(1.0)
					fllmov = source[2]
					time.sleep(30.0)
					fllmov = '0'
					pass
		elif parameters=='6':
					answer = u"KIDS CHANNELS : FROM 1 TO 4\n"
					for a, b in enumerate(KIDS):
						answer += u"%i. %s, " % (a + 1, b)
					reply(type, source, answer.encode("utf-8")+'\nsend channel number from 1 to 4 to view RTSP LINKS.'+reset)
					fllcat = '0'
					time.sleep(1.0)
					fllkid = source[2]
					time.sleep(30.0)
					fllkid = '0'
					pass
		elif parameters=='7':
					answer = u"LIFESTYLE CHANNELS : FROM 1 TO 3\n"
					for a, b in enumerate(LIFESTYLE):
						answer += u"%i. %s, " % (a + 1, b)
					reply(type, source, answer.encode("utf-8")+'\nsend channel number from 1 to 3 to view RTSP LINKS.'+reset)
					fllcat = '0'
					time.sleep(1.0)
					flllyf = source[2]
					time.sleep(30.0)
					flllyf = '0'
					pass
		elif parameters=='8':
					answer = u"DEVOTIONAL CHANNELS : FROM 1 TO 2\n"
					for a, b in enumerate(DEVOTIONAL):
						answer += u"%i. %s, " % (a + 1, b)
					reply(type, source, answer.encode("utf-8")+'\nsend channel number from 1 to 2 to view RTSP LINKS.'+reset)
					fllcat = '0'
					time.sleep(1.0)
					flldev = source[2]
					time.sleep(30.0)
					flldev = '0'
					pass
		else:
				reply(type, source, u'send catagory numbers from 1 to 8')
				return
	else:
			pass
   
def entertainment_msg(type,source,parameters):
	global fllen
	time.sleep(0.5)
	if fllen == source[2]:
		if parameters=='1':
				fllen = '0'
				reply('private',source, u'STAR PLUS :\nLOW35/livefeed/STARPLUS_QVGA.sdp')
				pass
		elif parameters=='2':
				fllen = '0'
				reply('private',source, u'ZOOM :\nHIGH - rtsp://121.241.249.136:1935/livefeed/ZOOM_QVGA.sdp')
				pass
		elif parameters=='3':
				fllen = '0'
				reply('private',source, u'SONY TV :\nLOW - rtsp://simplel9.136:1935/livefeed/SONYTV_QVGA.sdp')
				pass
		elif parameters=='4':
				fllen = '0'
				reply('private',source, u'STAR ONE :\nLOW - rtsp://sim.249.136:1935/livefeed/STARONE_QVGA.sdp')
				pass
		elif parameters=='5':
				fllen = '0'
				reply('private',source, u'SAB TV :\nLOW - rtsp://simplelive.nexg.tv:554/chmpeg/5/livefeed/SABTV_QVGA.sdp')
				pass
		elif parameters=='6':
				fllen = '0'
				reply('private',source, u'STAR UTSAV :\nLOW - rtsp://simplelive/STARUTSAV_QVGA.sdp')
				pass
		elif parameters=='7':
				fllen = '0'
				reply('private',source, u'NDTV GOODTIMES :\nCHANNEL LINK NOT AVALABLE AT THE MOMENT, TRY OTHER CHANNELS')
				pass
		elif parameters=='8':
				fllen = '0'
				reply('private',source, u'UTV STARS :\n2:554/prf1/cid_19.sdp \nHIGH - rtsp://115.112.249.202:554/prf2/cid_19.sdp')
				pass
		elif parameters=='9':
				fllen = '0'
				reply('private',source, u'UTV BINDAS :\n1/cid_20.sdp \nHIGH - rtsp://115.112.249.202:554/prf2/cid_20.sdp')
				pass
		else:
				reply(type, source, u'MENU RESET ! please try again !')
				fllen = '0'
				pass
	else:
			pass

def music_msg(type,source,parameters):
	global fllmu
	time.sleep(0.5)
	if fllmu == source[2]:
		if parameters=='1':
				fllmu = '0'
				reply('private',source, u'CHANNEL V :\nLOW - rtsp://simplelive.nexg.tv:554/chmpeg/channelv_mpeg.sdp')
				pass
		elif parameters=='2':
				fllmu = '0'
				reply('private',source, u'MUSIC INDIA :\nCHANNEL LINK NOT AVALABLE AT THE MOMENT, TRY OTHER CHANNELS')
				pass
		elif parameters=='3':
				fllmu = '0'
				reply('private',source, u'9XM :\nLOW - rtsp://3gp \nHIGH - rtsp://217.146.95.166:554/live/ch57yqvga.3gp')
				pass
		elif parameters=='4':
				fllmu = '0'
				reply('private',source, u'B4U MUSIC :\nLOW - rts2.248.159:554/prf1/c12.248.159:554/prf2/cid_75.sdp')
				pass
		elif parameters=='5':
				fllmu = '0'
				reply('private',source, u'ZING MUSIC :\nLOW - rtsp://217.146.95.1rtsp://217.146.95.166:554/live/ch28zqvga.3gp')
				pass
		elif parameters=='6':
				fllmu = '0'
				reply('private',source, u'BOLLYWOOD NIRWA.146.95.166:554/live/ch72yqvga.3gp')
				pass
		elif parameters=='7':
				fllmu = '0'
				reply('private',source, u'TASHAN :\nLOW - rtsp://11/cid_88.sdp \nHIGH - rtsp://115.112.248.159:554/prf2/cid_88.sdp')
				pass
		elif parameters=='8':
				fllmu = '0'
				reply('private',source, u'9XM JHAKKAS :\nLOW - rtsp://du.tv:554/pdu.tv:554/prf2/cid_92.sdp')
				pass
		elif parameters=='9':
				fllmu = '0'
				reply('private',source, u'MIAMI MUSIC :\nLOW - rts7.146.95.166:554/playlist/ch51yqvga.3gp')
				pass
		elif parameters=='10':
				fllmu = '0'
				reply('private',source, u'CHANNEL S BANGLA :\nLO://217.146.95.166:554/playlist/ch45yqvga.3gp')
				pass
		elif parameters=='11':
				fllmu = '0'
				reply('private',source, u'VIVA MUSIC :\nLOW - rtsp://217.://217.146.95.166:554/playlist/ch70yqvga.3gp')
				pass
		elif parameters=='12':
				fllmu = '0'
				reply('private',source, u'4 MUSIC TV :\nLOW - rtsp://17.146.95.166:554/playlist/ch69yqvga.3gp')
				pass
		elif parameters=='13':
				fllmu = '0'
				reply('private',source, u'SANGEET BHOJPURI :\nLOW - rts:.159:554/prf2/cid_83.sdp')
				pass
		else:
				reply(type, source, u'MENU RESET ! please try again !')
				fllmu = '0'
				pass
	else:
			pass

def news_msg(type,source,parameters):
	global fllnw
	time.sleep(0.5)
	if fllnw == source[2]:
		if parameters=='1':
				fllnw = '0'
				reply('private',source, u'AAJ TAK :\nCHANNEL LINK NOT AVALABLE AT THE MOMENT, TRY OTHER CHANNELS')
				pass
		elif parameters=='2':
				fllnw = '0'
				reply('private',source, u'HEADLINES TODAY :\nLOW - rtsp://ssGH - rtsp://ss1c6.idc.mundu.tv:554/prf2/cid_64.sdp')
				pass
		elif parameters=='3':
				fllnw = '0'
				reply('private',source, u'NDTV :\nCHANNEL LINK NOT AVALABLE AT THE MOMENT, TRY OTHER CHANNELS')
				pass
		elif parameters=='4':
				fllnw = '0'
				reply('private',source, u'NDTV 24 X 7 :\nCHANNEL LINK NOT AVALABLE AT THE MOMENT, TRY OTHER CHANNELS')
				pass
		elif parameters=='5':
				fllnw = '0'
				reply('private',source, u'NDTV PROFIT :\nCHANNEL LINK NOT AVALABLE AT THE MOMENT, TRY OTHER CHANNELS')
				pass
		elif parameters=='6':
				fllnw = '0'
				reply('private',source, u'TIMES NOW :\nCHANNEL LINK NOT AVALABLE AT THE MOMENT, TRY OTHER CHANNELS')
				pass
		elif parameters=='7':
				fllnw = '0'
				reply('private',source, u'IBN 7 :\nLOW - rtsp://simplelive.nexg.tv:5545/livefeed/IBN7_QVGA.sdp')
				pass
		elif parameters=='8':
				fllnw = '0'
				reply('private',source, u'IBN LOKMAT :\nLOW - rtsp://simplelive.nexg.tv:554/chmpeg/ibnlokmat.sdp')
				pass
		elif parameters=='9':
				fllnw = '0'
				reply('private',source, u'CNN IBN :\nLOW - rtsp://simplelive.nexg.tv:554/chmpeg/cnnibn.sdp')
				pass
		elif parameters=='10':
				fllnw = '0'
				reply('private',source, u'CNBC AAWAZ :\nCHANNEL LINK NOT AVALABLE AT THE MOMENT, TRY OTHER CHANNELS')
				pass
		elif parameters=='11':
				fllnw = '0'
				reply('private',source, u'CNBC TV18 :\nCHANNEL LINK NOT AVALABLE AT THE MOMENT, TRY OTHER CHANNELS')
				pass
		elif parameters=='12':
				fllnw = '0'
				reply('private',source, u'4 BLOOMBERG UTV :\nLOW - rtsp://115.112/115.112.249.202:554/prf2/cid_22.sdp')
				pass
		elif parameters=='13':
				fllnw = '0'
				reply('private',source, u'INDIA TV :\nLOW - rtsp://simplelive.nexg.tv:554/chmpeg/indiatv_mpeg.sdp')
				pass
		elif parameters=='14':
				fllnw = '0'
				reply('private',source, u'CNN INTERNATIONAL :\nLOW - rtsp://simplelive.nexg.tv:554/chmpeg/cnn_mpeg.sdp')
				pass
		elif parameters=='15':
				fllnw = '0'
				reply('private',source, u'SUVARNA NEWS :\nLOW - rtsp://simplelive.nexg.tv:554/chmpeg/suvarnanews_mpeg.sdp')
				pass
		elif parameters=='16':
				fllnw = '0'
				reply('private',source, u'RT NEWS :\nLOW - rtsp://217.146./217.146.95.166:554/live/ch35yqvga.3gp')
				pass
		elif parameters=='17':
				fllnw = '0'
				reply('private',source, u'TV9 :\nLOW - rtsp://simplelive.nexg.tv:554/chmpeg/tv9_mpeg.sdp')
				pass
		elif parameters=='18':
				fllnw = '0'
				reply('private',source, u'AAJTAK TEZ :\nLOW - rtsp://simplelive.nexg.tv:554/chmpeg/aajtaktez_mpeg.sdp')
				pass
		elif parameters=='19':
				fllnw = '0'
				reply('private',source, u'DELHI AAJTAK :\nLOW - rtsp://simplelive.nexg.tv:554/chmpeg/delhiaajtak_mpeg.sdp')
				pass
		elif parameters=='20':
				fllnw = '0'
				reply('private',source, u'DD NEWS :\nLOW - rtsp://simplelive.nexg.tv:554/chmpeg/ddnews_mpeg.sdp')
				pass
		elif parameters=='21':
				fllnw = '0'
				reply('private',source, u'PTC NEWS :\nLOW - rtsp://simplelive.nexg.tv:554/chmpeg/ptcnews_mpeg.sdp')
				pass
		elif parameters=='22':
				fllnw = '0'
				reply('private',source, u'NEWS 9 :\nLOW - rtsp://121.241.249.136:1935/livefeed/NEWS9_QVGA.sdp')
				pass

		else:
				reply(type, source, u'MENU RESET ! please try again !')
				fllnw = '0'
				pass
	else:
			pass

def science_msg(type,source,parameters):
	global fllsc
	time.sleep(0.5)
	if fllsc == source[2]:
		if parameters=='1':
				fllsc = '0'
				reply('private',source, u'HISTORY CHANNEL :\nHIGH - rtsp://121.241.249.136:1935/livefeed/HISTORY_QVGA.sdp')
				pass
		elif parameters=='2':
				fllsc = '0'
				reply('private',source, u'DISCOVERY CHANNEL :\nHIGH - rtsp://121.241.249.136:1935/livefeed/DISCOVERYCHANNEL_QVGA.sdp')
				pass
		elif parameters=='3':
				fllsc = '0'
				reply('private',source, u'DISCOVERY SCIENCE :\nHIGH - rtsp://121.241.249.136:1935/livefeed/DISCOVERYSCIENCE_QVGA.sdp')
				pass
		elif parameters=='4':
				fllsc = '0'
				reply('private',source, u'DISCOVERY TURBO :\nHIGH - rtsp://121.241.249.136:1935/livefeed/DISCOVERYTURBO_QVGA.sdp')
				pass
		elif parameters=='5':
				fllsc = '0'
				reply('private',source, u'ANIMAL PLANET :\nHIGH - rtsp://121.241.249.136:1935/livefeed/ANIMALPLANET_QVGA.sdp')
				pass
		else:
				reply(type, source, u'MENU RESET ! please try again !')
				fllen = '0'
				pass
	else:
			pass

def movies_msg(type,source,parameters):
	global fllmov
	time.sleep(0.5)
	if fllmov == source[2]:
		if parameters=='1':
				fllmov = '0'
				reply('private',source, u'UTV MOVIES :\nLOW - rtsp://115.112.2sdp \nHIGH - rtsp://115.112.249.202:554/prf2/cid_21.sdp')
				pass
		elif parameters=='2':
				fllmov = '0'
				reply('private',source, u'B4U MOVIES :\nLOW - rtsp://115.f1/c12.248.159:554/prf2/cid_74.sdp')
				pass
		elif parameters=='3':
				fllmov = '0'
				reply('private',source, u'BOLLYWOOD ACTIO146.95.166:554/playlist/ch32yqvga.3gp')
				pass
		elif parameters=='4':
				fllmov = '0'
				reply('private',source, u'BOLLYWOOD MOVIES N MUSIC :\nLOW - rtsp://217.146.playlist/ch33yqvga.3gp')
				pass
		elif parameters=='5':
				fllmov = '0'
				reply('private',source, u'MAA MOVIE :\nHIGH - rtsp://simplelive.nexg.tv:554/chmpeg/maamovie_mpeg.sdp')
				pass
		else:
				reply(type, source, u'MENU RESET ! please try again !')
				fllmov = '0'
				pass
	else:
			pass

def kids_msg(type,source,parameters):
	global fllkid
	time.sleep(0.5)
	if fllkid == source[2]:
		if parameters=='1':
				fllkid = '0'
				reply('private',source, u'CARTOON NETWORK :\nLOW - rts49.136:1935/livefeed/CARTOONNETWORK_QVGA.sdp')
				pass
		elif parameters=='2':
				fllkid = '0'
				reply('private',source, u'POGO CHANNEL :\nLOW - rtsp://siH - vefeed/POGO_QVGA.sdp')
				pass
		elif parameters=='3':
				fllkid = '0'
				reply('private',source, u'DISNEY HINDI :\nHIGH - rtsp://121.241.249.136:1935/livefeed/DISNEYHINDI_QVGA.sdp')
				pass
		elif parameters=='4':
				fllkid = '0'
				reply('private',source, u'DISNEY ENGLISH :\nHIGH - rtsp://121.241.249.136:1935/livefeed/DISNEYENGLISH_QVGA.sdp')
				pass
		else:
				reply(type, source, u'MENU RESET ! please try again !')
				fllkid = '0'
				pass
	else:
			pass

def lifestyle_msg(type,source,parameters):
	global flllyf
	time.sleep(0.5)
	if flllyf == source[2]:
		if parameters=='1':
				flllyf = '0'
				reply('private',source, u'FASHION TV :\nLOW - rtsp://217.146.//217.146.95.166:554/playlist/ch27yqvga.3gp')
				pass
		elif parameters=='2':
				flllyf = '0'
				reply('private',source, u'TRAVEL XP :\nLOW - rtsp://115.112.24848.159:554/prf2/cid_84.sdp')
				pass
		elif parameters=='3':
				flllyf = '0'
				reply('private',source, u'TLC :\nHIGH - rtsp://121.241.249.136:1935/livefeed/TLC_QVGA.sdp')
				pass
		else:
				reply(type, source, u'MENU RESET ! please try again !')
				flllyf = '0'
				pass
	else:
			pass

def devotional_msg(type,source,parameters):
	global flldev
	time.sleep(0.5)
	if flldev == source[2]:
		if parameters=='1':
				flldev = '0'
				reply('private',source, u'AASTHA TV :\nMEDIUM - rtsp://simplelive.nexg.tv:554/chmpeg/aastha_mpeg.sdp')
				pass
		elif parameters=='2':
				flldev = '0'
				reply('private',source, u'MH1 SHRADDHA :\nMEDIUM - rtsp://simplelive.nexg.tv:554/chmpeg/shradha_mpeg.sdp')
				pass
		else:
				reply(type, source, u'MENU RESET ! please try again !')
				flldev = '0'
				pass
	else:
			pass


register_message_handler(catagory_msg)
register_message_handler(entertainment_msg)
register_message_handler(music_msg)
register_message_handler(news_msg)
register_message_handler(science_msg)
register_message_handler(movies_msg)
register_message_handler(kids_msg)
register_message_handler(lifestyle_msg)
register_message_handler(devotional_msg)
register_command_handler(handler_tv, 'tv', ['fun','all'], 0, 'send "tv" to start.', 'tv', ['tv'])
