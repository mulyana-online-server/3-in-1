#--===auroraplugin===--
# -*- coding: utf-8 -*-
#  aurora plugin
#  love_plugin.py
#  coded by kf (kforkingfisher@/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########

vulgar_words = [u' madarchod ', u' gandu ', u' randi ', u' rand ', u' raand ', u' gand ', u' gaand ', u' gaandu ', u' chut ', u'choot', u' sali ', u' behanchod ', u' bahanchod ', u' land ', u' lund ', u' laude ', u' lauda ', u' chinal ', u' harami ', u' chodu ', u' bhadwe ', u' benchod ', u' gasti ', u' teri maa ', u' bhosra ', u' loda ', u' luda ', u'laude', u' pund ', u' pussy ', u' fussy ', u' penis ', u' laude ', u' gubba ', u' chudwaye ', u' fudu ', u' bhosda ', u' lode ', u' chutiya ', u' chutiye ', u' motherfuck ', u' motherfuck ', u' fuck ', u' fucker ', u' fuckoff ', u' fuckof ', u' fuckyou ', u' lulle ', u' lule ', u' _l_ ']

def check_vulgar_words(parameters):
	parameters=parameters.lower()
	parameters=u' '+parameters+u' '
	for x in vulgar_words:
		if parameters.count(x):
			return True
	return False

def handler_love(type, source, parameters):
	if parameters:
		raw = string.split(parameters, ' ', 2)
		if (len(raw)<2) or (len(raw)>2):
				reply(type, source, u'Should be 2 Names ! \nExample : Love Deepak Mona')
				return
		else:
			if check_vulgar_words(parameters):
				reply(type, source, u'Such Words cant be Calculated :-@')
				return
			else:
                       	 	parameters=parameters.split(' ')
                       	 	parameters1=parameters[0].strip().lower()
                       	 	parameters2=parameters[1].strip().lower()
                        	reply(type, source, parameters1+' <3 '+parameters2+' = '+str(random.randrange(100))+' % ')
				return
	else:
		reply(type, source, u'Provide Two Names ! \nExample : Love Deepak Mona')
			
register_command_handler(handler_love, 'love', ['muc','all'], 0, 'Calculates Love Percentage Between Two Peoples', 'Love <Your Name> <Crush Name>', ['Love Deepak Mona'])