#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  roulette_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################


def handler_roulette_one(type, source, parameters):
	groupchat = source[1]
	nick = source[2]
	rep =''
	if not user_level(source,groupchat)>=15:
		if GROUPCHATS.has_key(groupchat):
			if nick:
				random.seed(int(time.time()))
				if random.randrange(0,2) == 0:
					order_kick(source[1], nick, u'dichkionnnn!!!')
				else:
					rep = u'CLICK!'
		else:
			rep = u'dimag kaam nahi kar rha :(...'
		if rep:
			reply(type, source, rep)
		else:
			msg(source[1],  u'wo mara '+nick+u' ko :-D :-D')
	else:
		reply(type, source, u'mere haanth nahi uth rahe :-(')
	
#def handler_roulette_many(type, source, parameters):
	
	

register_command_handler(handler_roulette_one, 'shoot', ['fun','info','all'], 10, 'Russian roulette game.', 'shoot', ['shoot'])
