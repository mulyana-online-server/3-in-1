#--===auroraplugin===--
# -*- coding: utf-8 -*-
#  aurora plugin
#  shayari_plugin.py
#  coded by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

def handler_shayari(type, source, parameters):
   replies = [u'iltiza hai bas tujhe paane ki \naur koi hasrat nahi tere diwane ki \nshikwa mujhe tujhse nahi khuda se hai \nkya jarurat thi tujhe itna khubsurat banane ki :$' ,u'Khuda ne jb tje banaya hoga \nek suroor uske dil me aaya hoga \nsocha hoga kya dunga tohfe me \ntb jakar usne muje banaya hoga', u'Samandar Ki Khamosi Uski Gehrayi Batati Hai \nDosto Ki Kami Apni Tanhayi Batati Hai Vaise To Dost Hamesha Pyare Hote Hai \nPar Unki Kimat Unki Judayi Batati Hai ', u'Chaha tha humne jise use bhulaya na gaya \nJakham dil ka logon se chupaaya na gaya \nBewafai ke baad bhi itna pyar kiya hai ki \nBewafa ka iljaam bhi us par lagaya na gaya', u'Door jakar bhi hum door jaa na sakenge \nKitna royenge hum bata na sakenge \nGham iska nahi ki aap mil na sakoge \nDard is baat ka hoga ki hum aapko bhula nasakenge', u'Kismat ke hantho wo hi mazbur hote hai \njo haqikat se baht dur hote hai \nsaza aksar unhi ko milti hai \njo har tarah se BEKASUR hote hai', u'Muskan Ka Koi Mol Nahi Hota \nKuch Risto Ka Koi Tol Nhi Hota \nLog to Mil Jate He har Raste Par \nLekin Har Koi Aap Ki Tarah Anmol Nahi Hota ', u'Jeete The Kabhi Hum Bhi Shaan Se \nMehek Uthti Thi Fiza Kisi Ke Naam Se \nPar Guzre Hain Hum Kuch Aise Mukam Se \nKe NAFRAT Si Ho Gayi Hai MUHABBAT Ke Naam Se', u'Na Chaaho Itna Hame Chahoton Se Dar Lagta Hai \nNa Aao Itna Kareeb Judai Se Dar Lagta Hai \nTumhari Wafaon Pe Bharosa Hai Magar Apne Naseeb Se Dar Lagta Hai', u'Pyaar Woh Hai Jo Jazbaat Ko Samje \nMohabbat Woh Hai Jo Ehasas Ko Samje \nMil jate Hai Bahot Apna Kahna Wale \nPar Apna Tu Woh Hai Jo Bina Kahe Har Baat Ko Samje', u'Aarju jhoot hai kahani hai \nAarju ka fareb khana nhi \nkhush jo rahna hai zindgi mei tumhe \nDil kisise kabhi lagana nhi', u'Teri BeRukhi Ko Bhi Rutba Diya HumNe \nPyar Ka Har Farz Ada Kiya HumNe \nMat Soch Ke Hum BhuL Gaye Hain Tujhe \nAaj Bhi KhudSe PehLe Tujhe Yaad Kiya HumNe ', u'Aaj phir khuda ne mujh se pucha Tera hasta hua chera udas q hai \nBarasti nigahon me pyas kyun hai \nJinki nazro me tu kuch nahi \nWo tere liye khas kyun hai', u'Na Wo Aa Sake Na Hum Ja Sake \nDard DiL Ka Kisi Ko Na Suna Sake \nYaado Me Baithe Hai Lekar Aas Unki \nNa Unhone Yaad Kiya Na Hum Bhula Sake', u'Saans lene se bhi teri yaad aati hai \nHar saans mein teri khushboo bas jati hai \nKese kahoon ki saans se main zinda hoon \nJab ki saans se pehle teri yaad aati hai', u'Dil se roye magar hathon se muskara baithe \nYuhi hum tum se dil laga baithe \nWoh hame eklamha na de paye \nJinke liye hum apna sara sukun gawa baithe', u'Na hume pata tha na unhe \nhum dono hi rishte ki kasam nibhate rahe \nunhome hume chhora or khud jale or hume jalate rahe', u'Armano k silsile kahi bikhar na jaye \nIsliye apno ko bewaqt yad karte hai \nkahi unke dil se ham nikal na jaye']
   balas = random.choice(replies)
   if type == 'public':
      if source[1]:
         reply(type, source, balas)
   elif type == 'private':
      reply(type, source, balas)

def handler_shayar(type, source, parameters):
   replies = [u'me shayar to nahi :-P \nmagar aye haseen \njab se dekha tujhko mujhko \nshayari aa gyi :-$:-D']
   balas = random.choice(replies)
   if type == 'public':
      if source[1]:
         reply(type, source, balas)
   elif type == 'private':
      reply(type, source, balas)

def handler_wahwah(type, source, parameters):
   replies = [u'tq ji :$', u'achhi lagi shayari ?:$', u'aapko pasand aai shayari ?:$', u'mene khud likhi hai ye shayari :$', u'mujhe achhi-achhi shayari yaad hai :-P']
   balas = random.choice(replies)
   if type == 'public':
      if source[1]:
         reply(type, source, balas)
   elif type == 'private':
      reply(type, source, balas)

register_command_handler(handler_shayari, 'sher', ['new'], 0, '', '', [''])
register_command_handler(handler_shayari, 'shayari', ['new'], 0, '', '', [''])
register_command_handler(handler_shayari, 'shayeri', ['new'], 0, '', '', [''])
register_command_handler(handler_shayari, 'shayri', ['new'], 0, '', '', [''])
register_command_handler(handler_shayar, 'shayar', ['new'], 0, '', '', [''])
register_command_handler(handler_shayar, 'shayr', ['new'], 0, '', '', [''])
register_command_handler(handler_wahwah, 'wahwah', ['new'], 0, '', '', [''])
register_command_handler(handler_wahwah, 'wah', ['new'], 0, '', '', [''])
register_command_handler(handler_wahwah, 'waah', ['new'], 0, '', '', [''])
register_command_handler(handler_wahwah, 'waahwaah', ['new'], 0, '', '', [''])