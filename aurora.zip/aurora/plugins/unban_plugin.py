#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  unban_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################



        
def handler_unbanaf(type, source, parameters):
   count= parameters.split()[1]
   how = parameters.split()[2]
   jid = parameters.split()[0]
   iq = xmpp.Iq('set')
   iq.setID('ulti_ban')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#admin')
   for i in range(int(count), int(how)):
      count= int(count) + 1
      
      
      query.addChild('item', {'jid':jid+str(count)+'@nimbuzz.com', 'affiliation':'none'})
   iq.addChild(node=query)
   JCON.SendAndCallForResponse(iq, handler_unban_answ, {'type': type, 'source': source})







def handler_unbanbe(type, source, parameters):
   count= parameters.split()[1]
   how = parameters.split()[2]
   jid = parameters.split()[0]
   iq = xmpp.Iq('set')
   iq.setID('ulti_ban')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#admin')
   for i in range(int(count), int(how)):
      count= int(count) + 1
      
      
      query.addChild('item', {'jid':str(count)+jid+'@nimbuzz.com', 'affiliation':'none'})
   iq.addChild(node=query)
   JCON.SendAndCallForResponse(iq, handler_unban_answ, {'type': type, 'source': source})





def handler_unbanbt(type, source, parameters):
   count= parameters.split()[1]
   how = parameters.split()[2]
   jid = parameters.split()[0]
   iq = xmpp.Iq('set')
   iq.setID('ulti_ban')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#admin')
   for i in range(int(count), int(how)):
      count= int(count) + 1
      
      
      query.addChild('item', {'jid':jid+'-'+str(count)+'-@nimbuzz.com', 'affiliation':'none'})
   iq.addChild(node=query)
   JCON.SendAndCallForResponse(iq, handler_unban_answ, {'type': type, 'source': source})

def handler_unbanbt1(type, source, parameters):
   count= parameters.split()[1]
   how = parameters.split()[2]
   jid = parameters.split()[0]
   iq = xmpp.Iq('set')
   iq.setID('ulti_ban')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#admin')
   for i in range(int(count), int(how)):
      count= int(count) + 1
      
      

      query.addChild('item', {'jid':jid+str(count)+jid+'@nimbuzz.com', 'affiliation':'none'})
   iq.addChild(node=query)
   JCON.SendAndCallForResponse(iq, handler_unban_answ, {'type': type, 'source': source})


def handler_unban_answ(coze, res, type, source):
   if res:
      if res.getType() == 'result':
         reply(type, source, u'Unbanned.')
      else:
         
         reply(type, source, u'Error. Try again, or unban less quantity.')





register_command_handler(handler_unbanaf, 'unban-', ['info','muc','all'], 20, 'unBan serial IDs with number after', 'unban-', ['unban-'])
register_command_handler(handler_unbanbe, '-unban', ['info','muc','all'], 20, 'unBan serial IDs with number before', '-unban', ['-unban'])
register_command_handler(handler_unbanbt, '-unban-', ['info','muc','all'], 20, 'unBan serial IDs with number between --', '-unban-', ['-unban-'])
register_command_handler(handler_unbanbt1, '-un-ban-', ['info','muc','all'], 20, 'unBan serial IDs with number between same two words', '-un-ban-', ['-un-ban-'])