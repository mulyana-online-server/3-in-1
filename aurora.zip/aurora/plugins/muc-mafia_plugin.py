#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  muc-mafia_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################


def handler_makeadmin(type, source, parameters):
   reply(type, source, u'Ok')
   nick=parameters
   iq = xmpp.Iq('set')
   iq.setID('ulti_admin')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#admin')
   query.addChild('item', {'nick':nick, 'role':'moderator'})
   query.addChild('item', {'jid':nick+'@nimbuzz.com', 'affiliation':'admin'})
   iq.addChild(node=query)
   JCON.send(iq)

def handler_makeowner(type, source, parameters):
   reply(type, source, u'Ok')
   nick=parameters
   iq = xmpp.Iq('set')
   iq.setID('ulti_owner')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#admin')
   query.addChild('item', {'nick':nick, 'role':'moderator'})
   query.addChild('item', {'jid':nick+'@nimbuzz.com', 'affiliation':'owner'})
   iq.addChild(node=query)
   JCON.send(iq) 

def handler_makemember(type, source, parameters):
   reply(type, source, u'membered')
   nick=parameters
   iq = xmpp.Iq('set')
   iq.setID('ulti_member')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#admin')
   query.addChild('item', {'jid':nick+'@nimbuzz.com', 'affiliation':'member'})
   iq.addChild(node=query)
   JCON.send(iq)  

def handler_makeunban(type, source, parameters):
   reply(type, source, u'unbanned')
   nick=parameters
   iq = xmpp.Iq('set')
   iq.setID('ulti_unban')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#admin')
   query.addChild('item', {'jid':nick+'@nimbuzz.com', 'affiliation':'none'})
   iq.addChild(node=query)
   JCON.send(iq)

def handler_makeunmember(type, source, parameters):
   reply(type, source, u'unmembered')
   nick=parameters
   iq = xmpp.Iq('set')
   iq.setID('ulti_unban')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#admin')
   query.addChild('item', {'jid':nick+'@nimbuzz.com', 'affiliation':'none'})
   iq.addChild(node=query)
   JCON.send(iq)

def handler_makeban(type, source, parameters):
   reply(type, source, u'banned')
   nick=parameters
   iq = xmpp.Iq('set')
   iq.setID('ulti_outcast')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#admin')
   query.addChild('item', {'jid':nick+'@nimbuzz.com', 'affiliation':'outcast'})
   iq.addChild(node=query)
   JCON.send(iq)
  
def handler_makevisitor(type, source, parameters):
   reply(type, source, u'he is now visitor')
   nick=parameters
   iq = xmpp.Iq('set')
   iq.setID('ulti_visitor')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#admin')
   query.addChild('item', {'nick':nick, 'role':'visitor'})
   query.addChild('item', {'jid':nick+'@nimbuzz.com', 'affiliation':'none'})
   iq.addChild(node=query)
   JCON.send(iq)

def handler_makeparticipant(type, source, parameters):
   reply(type, source, u'he is now participant')
   nick=parameters
   iq = xmpp.Iq('set')
   iq.setID('ulti_participant')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#admin')
   query.addChild('item', {'nick':nick, 'role':'participant'})
   query.addChild('item', {'jid':nick+'@nimbuzz.com', 'affiliation':'none'})
   iq.addChild(node=query)
   JCON.send(iq)

def handler_makekick(type, source, parameters):
   reply(type, source, u'kicked')
   nick=parameters
   iq = xmpp.Iq('set')
   iq.setID('ulti_kick')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#admin')
   query.addChild('item', {'nick':nick, 'role':'none'})
   query.addChild('item', {'jid':nick+'@nimbuzz.com', 'affiliation':'none'})
   iq.addChild(node=query)
   JCON.send(iq)


register_command_handler(handler_makeadmin, 'a@', ['info','muc','all'], 100, 'Make admin+mod', 'a@ <jid>', ['a@ kforkingfisher'])
register_command_handler(handler_makeowner, 'o@', ['info','muc','all'], 100, 'Make owner+mod', 'o@ <jid>', ['o@ kforkingfisher'])
register_command_handler(handler_makemember, 'm@', ['info','muc','all'], 100, 'Make member', 'm@ <jid>', ['m@ kforkingfisher'])
register_command_handler(handler_makekick, 'k@', ['info','muc','all'], 100, 'kicks the user', 'k@ <jid>', ['k@ kforkingfisher'])
register_command_handler(handler_makeban, 'b@', ['info','muc','all'], 100, 'bans the user', 'b@ <jid>', ['b@ kforkingfisher'])
register_command_handler(handler_makevisitor, 'v@', ['info','muc','all'], 100, 'make the user visitor', 'v@ <jid>', ['v@ kforkingfisher'])
register_command_handler(handler_makeparticipant, 'p@', ['info','muc','all'], 100, 'make user participant', 'p@ <jid>', ['p@ kforkingfisher'])
register_command_handler(handler_makeunban, 'ub@', ['info','muc','all'], 100, 'unban the user', 'ub@ <jid>', ['ub@ kforkingfisher'])
register_command_handler(handler_makeunmember, 'um@', ['info','muc','all'], 100, 'unmember the user', 'um@ <jid>', ['um@ kforkingfisher'])