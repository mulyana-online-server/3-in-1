#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  muc_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

def handler_ban_everywhere(type, source, jid):
	gch=source[1]
	for gch in GROUPCHATS.keys():
	    order_banjid(gch, jid, u'go to hell')
	reply(type, source, u'banned everywhere')
	return

def handler_unban_everywhere(type, source, jid):
	gch=source[1]
	for gch in GROUPCHATS.keys():
	    order_unban(gch, jid)
	reply(type, source, u'unbanned everywhere')
	return

def handler_member_everywhere(type, source, jid):
	gch=source[1]
	for gch in GROUPCHATS.keys():
	    order_member(gch, jid, u'congratulations! Be a good member')
	reply(type, source, u'membered everywhere')
	return

def handler_unmember_everywhere(type, source, jid):
	gch=source[1]
	for gch in GROUPCHATS.keys():
	    order_unmember(gch, jid)
	reply(type, source, u'unmembered everywhere')
	return


def order_unban(groupchat, jid):
	iq = xmpp.Iq('set')
	iq.setTo(groupchat)
	iq.setID('kick'+str(random.randrange(1000, 9999)))
	query = xmpp.Node('query')
	query.setNamespace('http://jabber.org/protocol/muc#admin')
	query.addChild('item', {'jid':jid, 'affiliation':'none'})
	iq.addChild(node=query)
	JCON.send(iq)


def order_banjid(groupchat, jid, reason):
	iq = xmpp.Iq('set')
	iq.setTo(groupchat)
	iq.setID('ban'+str(random.randrange(1000, 9999)))
	query = xmpp.Node('query')
	query.setNamespace('http://jabber.org/protocol/muc#admin')
	ban=query.addChild('item', {'jid':jid, 'affiliation':'outcast'})
	ban.setTagData('reason', get_bot_nick(groupchat)+u': '+reason)
	iq.addChild(node=query)
	JCON.send(iq)

def order_member(groupchat, jid, reason):
	iq = xmpp.Iq('set')
	iq.setTo(groupchat)
	iq.setID(str(random.randrange(1000, 9999)))
	query = xmpp.Node('query')
	query.setNamespace('http://jabber.org/protocol/muc#admin')
	ban=query.addChild('item', {'jid':jid, 'affiliation':'member'})
	ban.setTagData('reason', get_bot_nick(groupchat)+u': '+reason)
	iq.addChild(node=query)
	JCON.send(iq)


def order_unmember(groupchat, jid):
	iq = xmpp.Iq('set')
	iq.setTo(groupchat)
	iq.setID(str(random.randrange(1000, 9999)))
	query = xmpp.Node('query')
	query.setNamespace('http://jabber.org/protocol/muc#admin')
	query.addChild('item', {'jid':jid, 'affiliation':"none"})
	iq.addChild(node=query)
	JCON.send(iq)

register_command_handler(handler_member_everywhere, 'fullmember', ['superadmin','all'], 100, 'member a jid everywhere where bot sits in conference', 'fullmember <jid>', ['fullmember guy@jsmart.web.id'])
register_command_handler(handler_unmember_everywhere, 'fullunmember', ['superadmin','all'], 100, 'unmember a jid everywhere where bot sits in conference', 'fullunmember <jid>', ['fullunmember guy@jsmart.web.id'])
register_command_handler(handler_ban_everywhere, 'fullban', ['superadmin','all'], 100, 'ban a jid everywhere where bot sits in conference', 'fullban <jid>', ['fullban guy@jsmart.web.id'])
register_command_handler(handler_unban_everywhere, 'fullunban', ['superadmin','all'], 100, 'unban a jid everywhere bot sits', 'fullunban <jid>', ['fullunban guy@jsmart.web.id'])
