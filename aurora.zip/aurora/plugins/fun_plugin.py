#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  fun_plugin.py
#  coded by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

def handler_facts(type, source, parameters):
   replies = [u'faamiya ko smiling emo pasand nei :-):-):-):-):-):-):-)le faamiya :-D', u'mona ko sleeping emo se shakt nafrat hai I-) sorryyy mona :-#', u'nani :-O ko ye emo bilkul nei pasand :-D', u'sanu ki shadi hone wali hai :-o', u' kf ne daru chod di 8[] :-D', u'sandeep doctor ,waqeel, engineer sb hai :D', u'aryan ko acp banna hai :-D', u'atif saifi :-# nida ko line marta hai :-#', u'kf mona pe fida hai :$', u'araab ab sudhar gaya hai :D lollzzz', u'kf nim me sabse jyada sayeed se darta hai :-#', u'nawaz ki smile aaaj b nei badli hai :-) :-D', u'usmaan k thode thode baal aane lage hai :-P', u'wulfu baat baat par gussa hoke dc mar deta hai :-#', u'sana k sir me baal kam hai :-# aur nimbuzz me bhai jyada hai :-|', u'aryan (~aryan~) ne gali dene me PHD hasil ki hai :-D', u'mona ko bot se sakht nafrat hai :-|', u'pure rum k deewaron pe sana aur faamiya k lipstic k nishaan hai', u'sonu hamesha bye bolne k baad intejaar krta hai k koi use rok le :-# :-D', u'sayeed agar hase to samajh jao ki uski tabiyat kharab hai :-#', u'log ek hafte tak apne status me likh k rakhte "aaj mera aakhri din hai nim me ,bubye alll:)" aur ek hafte baad status change kr dete :-#', u'Rohit uncle ki shadi kb hogi :-#', u'nani chupke-chupke kisiko line marta hai :-#', u'famiya ki bdi bdi khubsurat ankho ka raaz kya he :-O', u'Akram bahot bhola bhala nek sharif bacha he:-)', u'Kf chirkut he :-#', u'Mohsin bahot handsome he uspe ladkiya toot padti he kauve ki tarah :$', u'mohsin jiya ko moti bhainsi bulata hai :-#', u'palak ko me bahut pasand hu :$', u'meri gf ka naam batao to janu :$', u'jiya bahut achhi hai :-P']
   balas = random.choice(replies)
   if type == 'public':
      if source[1]:
         msg(source[1], balas)
   elif type == 'private':
      reply(type, source, balas)

register_command_handler(handler_facts, 'fun', ['new'], 0, '', '', [''])
register_command_handler(handler_facts, 'secret', ['new'], 0, '', '', [''])


