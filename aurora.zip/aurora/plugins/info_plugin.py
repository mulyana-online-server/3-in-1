#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  info_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################


def handler_getrealjid(type, source, parameters):
	groupchat=source[1]
	if GROUPCHATS.has_key(groupchat):
		nicks = GROUPCHATS[groupchat].keys()
		nick = parameters.strip()
		if not nick in nicks:
			reply(type,source,u'pakka <'+nick+u'> yaha hai ?')
			return
		else:
			jidsource=groupchat+'/'+nick
			if get_true_jid(jidsource) == 'None':
				reply(type, source, u'me moderator nahi hu :-(')
				return
			truejid=get_true_jid(jidsource)
			if type == 'public':
				reply(type, source, u'sent to private')
		reply('private', source, u'true jid <'+nick+u'> --> '+truejid)
		
		
def handler_total_in_muc(type, source, parameters):
	groupchat=source[1]
	if GROUPCHATS.has_key(groupchat):
		inmuc=[]
		for x in GROUPCHATS[groupchat].keys():
			if GROUPCHATS[groupchat][x]['ishere']==1:
				inmuc.append(x)
		reply(type, source, u'mjhe yaha itne log dikh rhe '+str(len(inmuc))+u' users\n'+u', '.join(inmuc))
	else:
		reply(type, source, u'maaf kijiyega')
		
		
def handler_bot_uptime(type, source, parameters):
	if INFO['start']:
		uptime=int(time.time() - INFO['start'])
		rep = u'\n- Session PID: '+str(os.getpid())
		rep += u'\n- Working time: '+timeElapsed(uptime)
		rep += u'\n- Messages posted: %s\n- Presences proceed: %s\n- Iq-queries proceed: %s\n- Commands executed: %s' % (str(INFO['msg']),str(INFO['prs']),str(INFO['iq']),str(INFO['cmd']))
		if os.name=='posix':
			try:
				pr = os.popen('ps -o rss -p %s' % os.getpid())
				pr.readline()
				mem = pr.readline().strip()
			finally:
				pr.close()
			if mem: rep += u'\n- Memory usage: %s Kb ' % mem
		(user, system,qqq,www,eee,) = os.times()
		rep += u'\n- CPU time spent: %.2f seconds\n- System time spent: %.2f seconds\n- Total system-wide time: %.2f seconds' % (user, system, user + system)
		rep += u'\n- Total generated streams: %s\n- Total active streams: %s ' % (INFO['thr'], threading.activeCount())
	else:
		rep = u'*PARDON*'
	reply(type, source, rep)

def handler__global_details(type, source, parameters):
	if type == 'public':
		return
	if parameters:
		param=parameters.split()
		if param[0] == 'admins':
			rep=''
			for x in BOT_ADMINS:
				rep+=x
				rep+='\n'
			reply(type, source, 'Global Admins :\n'+rep)
		if param[0] == 'pass':
			reply(type, source, 'Global password = '+ADMIN_PASSWORD)
		if param[0] == 'bot':
			reply(type, source, 'Bot password = '+BOT_PASSWORD)

register_command_handler(handler_getrealjid, 'truejid', ['info','admin','muc','all'], 20, 'Real JID of the indicated nick shows. Works only if a bot is a moderator certainly', 'truejid <nick>', ['truejid Pily'])
register_command_handler(handler_total_in_muc, 'here', ['info','admin','muc','all'], 10, 'Shows the amount of users being in a conference.', 'here', ['here'])
register_command_handler(handler_bot_uptime, 'botup', ['info','admin','all'], 10, 'Shows how many time a bot works without falling.', 'botup', ['botup'])
register_command_handler(handler__global_details, 'global', ['superadmin'], 100, 'Shows Global Details', 'global', ['global'])